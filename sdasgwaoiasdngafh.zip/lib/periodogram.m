function psd = periodogram(x, nfft)
% PERIODOGRAM Return estimated power spectral density (PSD) using the
% nonparametric method of periodogram
%----------------------------------------------------------------------------
% According to parseval's theorem, signal power in time domain is equal to
% signal power in frequency domain. However, due to normalization used in
% Matlab, the power integrated in frequency domain via fft should be scaled
% by 1/N, i.e.,
%
%   power_in_time = x' * x / N = power_in_frequency = fft(x)' * fft(x) / N^2
%
% However, the periodogram is not power per Hz, rather power per frequency
% bin of fft, varying with the frequency resolution. To show the true psd,
% the periodogram should be divided further by the frequency resolution.
% 
% Note that periodogram is an inconsistant PSD estimator in the sense of
% nonvanishing variance as number of data samples going to infinity. The
% increasingly "ragged" nature of the estimated PSD results from the larger
% number of independent estimated frequency components of DFT, causing the
% more rapid fluctuations in the PSD.
%----------------------------------------------------------------------------
if nargin < 2, nfft = length(x); end
psd = abs(fft(x, nfft)) .^ 2 / (nfft * nfft);


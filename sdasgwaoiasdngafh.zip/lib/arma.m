function x = arma(nrow, ncol, arcf, macf, varw)
% ARMA Generate ARMA time series with specified AR/MA coefficients
%----------------------------------------------------------------------------
% Syntax: x = arma(nrow, ncol, order, arcf, macf)
% Inputs: varw - variance of exciting white gaussian noise
%----------------------------------------------------------------------------
raw = randn(nrow, ncol);
w = sqrt(varw) * raw / sqrt(mean(raw.^2));
x = filter(macf, arcf, w);

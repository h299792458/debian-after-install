function [dspOut1, dspOut2, dspState] = dsp_main(xi, xq, yi, yq, dspParam)
% DSP_MAIN Main DSP testing funtion for offline processing
%----------------------------------------------------------------------------
% Using circular boundary condition for adaptive equalizer convergence. 
% 
% Syntax: [dspOut1, dspOut2, dspState] = dsp_main(xi, xq, yi, yq, dspParam)
% 
% Note: All units are international standard units
%----------------------------------------------------------------------------

dspState = [];
fprintf(strcat(datestr(now), sprintf('  processing %d input samples ', 4 * length(xi))));
fprintf('\n');
%----------------------------------------------------------------------------
% remove the dc component
%----------------------------------------------------------------------------
XI = xi - mean(xi);
XQ = xq - mean(xq);
YI = yi - mean(yi);
YQ = yq - mean(yq);
%----------------------------------------------------------------------------
% normalize the mean power
%----------------------------------------------------------------------------
XI = XI / calcrms(XI);
XQ = XQ / calcrms(XQ);
YI = YI / calcrms(YI);
YQ = YQ / calcrms(YQ);
%----------------------------------------------------------------------------
% remove the non-numerical data
%----------------------------------------------------------------------------
XI(isnan(XI)) = 0;
XQ(isnan(XQ)) = 0;
YI(isnan(YI)) = 0;
YQ(isnan(YQ)) = 0;

XI = XI(:);
YI = YI(:);
XQ = XQ(:);
YQ = YQ(:);
%----------------------------------------------------------------------------
% the power spectral density
%----------------------------------------------------------------------------
dataX = XI + 1i * XQ;
dataY = YI + 1i * YQ;
pxx = periodogram(dataX);
pyy = periodogram(dataY);
%----------------------------------------------------------------------------
if dspParam.showEye
    plotEyeDiagram(xi+1i*xq,dspParam.adcFs/dspParam.Rs*3,'e');
end
%----------------------------------------------------------------------------
if dspParam.doDigitalLPF
    [xi, xq, yi, yq] = LowpassFilter(samplingRate,Pa_Bw,xi,xq,yi,yq);
end
%----------------------------------------------------------------------------
REAL_DATA = [XI, XQ, YI, YQ];
%----------------------------------------------------------------------------
if dspParam.showEye
    plotEyeDiagram(xi+1i*xq,dspParam.adcFs/dspParam.Rs*3,'e');
end
%----------------------------------------------------------------------------
sps = dspParam.sps;
%----------------------------------------------------------------------------
% need to implement a realistic resampling algorithm here
%----------------------------------------------------------------------------
fprintf(strcat(datestr(now), '  performing digital resampling \n'));
[up, down] = rat(dspParam.Rs * sps / dspParam.fsADC);
if up == down
    % do nothing
elseif up == 1
	XI = XI(1 : down : end, 1);
	YI = YI(1 : down : end, 1);
	XQ = XQ(1 : down : end, 1);
	YQ = YQ(1 : down : end, 1);
else
    XI = resample(XI, up, down);
	YI = resample(YI, up, down);
	XQ = resample(XQ, up, down);
	YQ = resample(YQ, up, down);
end
%----------------------------------------------------------------------------
fs = dspParam.Rs * sps;
%----------------------------------------------------------------------------
rawX = XI + 1i * XQ;
rawY = YI + 1i * YQ;
%----------------------------------------------------------------------------
% Perform front-end impariment compensation
%----------------------------------------------------------------------------
if dspParam.doFrontEndComp
    fprintf(strcat(datestr(now), '  performing receiver front-end compensation \n'));
    fecX = orthogonalization(rawX);
	fecY = orthogonalization(rawY);
else
    fecX = rawX; fecY = rawY;
end

nsample = length(fecX);
%----------------------------------------------------------------------------
% Perform chromatic disperion estimation
%----------------------------------------------------------------------------
if dspParam.doCDE
    fprintf(strcat(datestr(now), '  performing chromatic dispersion estimation \n'));
end
%----------------------------------------------------------------------------
% Perform chromatic dispersion compensation
%----------------------------------------------------------------------------
if dspParam.doCDC
    fprintf(strcat(datestr(now), '  performing chromatic dispersion compensation \n'));
	[dspState.HCD] = chromdisp(nsample, fs, dspParam.lambda, dspParam.lambda0, dspParam.DL, dspParam.SL);
	cdcx = ifft(fft(fecX) .* conj(dspState.HCD));
	cdcy = ifft(fft(fecY) .* conj(dspState.HCD));
else
    cdcx = fecX; cdcy = fecY;
end
%----------------------------------------------------------------------------
% Perform an one-tap poldemux prior to timing recovery
%----------------------------------------------------------------------------
if dspParam.doOneTapPolDemux
    fprintf(strcat(datestr(now), '  performing one-tap polarization demultiplexing \n'));
    N = dspParam.trainingLengthOneTapPolDemux;
    As = [dspParam.refBaudX(1:N), dspParam.refBaudY(1:N)];
    Bs = [cdcx(1:2:2*N), cdcy(1:2:2*N)];
    % the wiener filter
    dspState.mimo_matrix = conj(As' * Bs / (Bs' * Bs));
    [cdcx, cdcy] = poltransfer(dspState.mimo_matrix, cdcx, cdcy);
else
    dspState.mimo_matrix = eye(2);
end

if dspParam.doTPE
    fprintf(strcat(datestr(now), '  performing digital timing recovery \n'));
else
    tpex = cdcx; tpey = cdcy;
    dspState.tpe_phase = [];
end
%----------------------------------------------------------------------------
% One can choose to retain the sps after the timing stage, or downsample
% here manually to 1 sps.
%----------------------------------------------------------------------------
if dspParam.doDownSampling
    fprintf(strcat(datestr(now), '  performing digital downsampling \n'));
	tpex = tpex(1 : 2 : end);
	tpey = tpey(1 : 2 : end);
	sps = 1;
end
%----------------------------------------------------------------------------
% Full poldemux
%----------------------------------------------------------------------------
if dspParam.doMIMO
    fprintf(strcat(datestr(now), '  performing dual-polarization equalization \n'));
else
    cmax = tpex; cmay = tpey;
    dspState.mimo_mse = [];
end
%----------------------------------------------------------------------------
% Perform CFO estimation and compensation
%----------------------------------------------------------------------------
if dspParam.doFOE
    fprintf(strcat(datestr(now), '  performing frequency offset estimation \n'));
else
    dspState.cfo = 0;
end
%----------------------------------------------------------------------------
% Perform carrier phase recovery
%----------------------------------------------------------------------------
if dspParam.doCPE
    fprintf(strcat(datestr(now), '  performing carrier recovery \n'));
	switch dspParam.cpeAlgSelect
		case 'BPS'
            dspState.cpe_phasex = estimateCarrierPhaseBPS(cmax, dspParam.cpeBlockSize, dspParam.cpeBPSnTestPhase, dspParam.mn);
            dspState.cpe_phasey = estimateCarrierPhaseBPS(cmay, dspParam.cpeBlockSize, dspParam.cpeBPSnTestPhase, dspParam.mn);
		case 'VVPE'
            dspState.cpe_phasex = estimateCarrierPhaseVV(cmax, dspParam.cpeBlockSize, dspParam.vvpeAvgMode);
            dspState.cpe_phasey = estimateCarrierPhaseVV(cmay, dspParam.cpeBlockSize, dspParam.vvpeAvgMode);
		case 3
			% TBA
		otherwise
			warning('unsupported cpe algorithm'); keyboard;
    end
    cpex = cmax .* exp(-1i * dspState.cpe_phasex);
    cpey = cmay .* exp(-1i * dspState.cpe_phasey);
else
    cpex = cmax; cpey = cmay;
    dspState.cpe_phasex = [];
	dspState.cpe_phasey = [];
end
%----------------------------------------------------------------------------
% Perform CPE based on ML
%----------------------------------------------------------------------------
if dspParam.doMLCPE
% 	cpeX = cpe_mle(cpeX,dspParam.cpeMlBlkSize,dspParam.cpeMlIter,dspParam.mn);
% 	cpeY = cpe_mle(cpeY,dspParam.cpeMlBlkSize,dspParam.cpeMlIter,dspParam.mn);
end
%----------------------------------------------------------------------------
% Perform LMS equalization after CPE
%----------------------------------------------------------------------------
if dspParam.doLmsAfterCPE
    fprintf(strcat(datestr(now), '  performing lms after carrier recovery \n'));
    lmsx = lms_sng_eq(cpex, dspParam.mn, sps, dspParam.lmsGainAfterCPE, dspParam.lmsTapsAfterCPE, dspParam.lmsIterAfterCPE);
    lmsy = lms_sng_eq(cpey, dspParam.mn, sps, dspParam.lmsGainAfterCPE, dspParam.lmsTapsAfterCPE, dspParam.lmsIterAfterCPE);
else
	lmsx = cpex;
	lmsy = cpey;
end
%----------------------------------------------------------------------------
dspOut1 = normalization(lmsx, dspParam.mn);
dspOut2 = normalization(lmsy, dspParam.mn);

fprintf(strcat(datestr(now), sprintf('  output %d samples ', 2 * length(lmsx))));
fprintf('\n');
function s = jones2stokes(ex, ey)
%----------------------------------------------------------------------------
% Transfer Jones vector to normalized Stokes vector
%----------------------------------------------------------------------------
% input Jones vector either in time or freq domain
e_in = [ex(:), ey(:)].';

% Pauli matrix
sigma = {[1,0;0,-1],[0,1;1,0],[0,-1i;1i,0]};

N = length(e_in(1,:));
s = zeros(3,N);
for ii = 1:3
    s(ii) = e_in' * sigma{ii} * e_in;
end

% normalize
s = [s(1,:); s(2,:); s(3,:)] ./ norm(s);
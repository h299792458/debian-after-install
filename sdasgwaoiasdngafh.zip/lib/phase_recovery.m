function [s, phi] = phase_recovery(x, ts, mn, stepsize, phi_ini)
% PHASE_RECOVERY Carrier phase recovery
%----------------------------------------------------------------------------
% Syntax: [s, phi] = phase_recovery(x, ts, mn, stepsize, phi_ini)
% 
% Inputs: 
% 
% Implementing the decision-directed phase-locked loop to estimate the
% carrier phase based on the least squares criteria and stochastic gradient
% descent algorithm.
%----------------------------------------------------------------------------
if nargin < 5, phi_ini = 0; end
if isrow(x), x = x.'; end
s    = zeros(size(x));
grad = zeros(size(x));
gint = zeros(size(x));
phi  = zeros(size(x));

% initialize stochastic gradient algorithm with least squares criteria
s(1)    = x(1);
phi(1)  = phi_ini;
gint(1) = 0;

% loop filter up to 2nd order
if length(stepsize) == 1
	mu1 = stepsize;
    mu2 = 0;
else
	mu1 = stepsize(1);
	mu2 = stepsize(2);
end

for k = 2 : length(x)
    s(k) = x(k) .* exp(-1i * phi(k-1));
    
    % decision directed
    if isnan(ts(k))
        signal = slicer(ts(k), mn);
    else
        signal = ts(k);
    end
    
    % stochastic gradient
    grad(k) = -imag(s(k) .* conj(signal));
    
    % error integration
    gint(k) = gint(k-1) + grad(k);
    
    % update filter coeff. along opposite direction of gradient
    phi(k) = phi(k-1) - mu1*grad(k) - mu2*gint(k);
end

function [y, fcoef] = linear_equalizer(x, ts, mf, alg, gain, lambda, flen)
% LINEAR_EQUALIZER Linear adaptive filter with either peak distortion or
% least squares criteria. Four specific algorithms are implemented, i.e.,
% zero-forcing (ZF), least mean squares (LMS), recursive least squares
% (RLS), and decision-feedback equalization (DFE).
%----------------------------------------------------------------------------
% Syntax: [y, fcoef] = linear_equalizer(x, ts, mf, alg, gain, lambda, flen)
%
% Inputs: x      - column vector, measured data to be filtered 
%         ts     - column vector, training sequence with same size of input 'x', 
%                  when tx is NAN, the filter will switch to decision
%                  directed mode
%         mf     - string, modulation format, e.g. 'QPSK', '16QAM'
%         alg    - string, name of algorithm, e.g. 'ZF', 'LMS', 'RLS'
%         gain   - scalar, gain factor, could be [] in RLS case
%         lambda - scalar, forgetting factor, could be [] in ZF and LMS cases
%         flen   - scalar in cases of ZF, LMS, RLS, filter-tap length;
%                  vector in case of DFE
%
% Note: # LINEAR_EQUALIZER will extend the input data by few samples first 
%         to start the algorithm
%       # Note the numerical stability problem of conventional RLS algorithm 
%       # Note the normalization realization of LMS algorithm 
%
% TODO: add fractional-spaced option
%----------------------------------------------------------------------------
if ~(length(x) == length(ts))
    warning('data and training should have same size'); keyboard;
end
if ~iscolumn(x)
    warning('column vector input required'); keyboard;
end
if strcmpi(alg, 'dfe') && numel(flen) ~= 2
    warning('input size of DFE filter length incorrect'); keyboard;
end
y = zeros(size(x));
switch lower(alg)
    case 'zf'
        % todo
    case 'lms'
        % extend measured data
        x_ext = zero_pad(x, flen-1, 'front');
        % initialization - filter coefficients
        fcoef = zeros(flen, length(x) - flen + 2);
        for ii = 1 : length(x) - flen + 1
            xx = x_ext((1 : flen) + (ii - 1));
            y(ii) = xx.' * fcoef(:, ii);
            if isnan(ts(ii)); target = slicer(y(ii), mf2mn(mf)); else target = ts(ii); end
            fcoef(:, ii + 1) = fcoef(:, ii) - gain * (y(ii) - target) * conj(xx) ./ (abs(xx) + eps);
% alternative implementation...
% y(ii) = xx' * fcoef(:, ii);
% fcoef(:, ii + 1) = fcoef(:, ii) - gain * (y(ii) - conj(target)) * xx ./ (abs(xx) + eps);
        end
    case 'rls'
        % extend measured data
        x_ext = zero_pad(x, flen-1, 'front');
        % initialization - filter coefficients
        fcoef = zeros(flen, length(x) - flen + 2);
        % initialization - covariance matrix
        sigma = 1e5 * eye(flen);
        for ii = 1 : length(x) - flen + 1
            xx = x_ext((1 : flen) + (ii - 1));
            gain = sigma * xx / (1.0*lambda + xx' * sigma * xx);
            y(ii) = xx.' * fcoef(:, ii);
            if isnan(ts(ii)); target = slicer(y(ii), mf2mn(mf)); else target = ts(ii); end
            fcoef(:, ii + 1) = fcoef(:, ii) + conj(gain) * (target - y(ii));
            sigma = (1/lambda) * (eye(flen) - gain * xx') * sigma;
        end
    case 'dfe'
        ff_len = flen(1);
        fb_len = flen(2);
        % extend measured data
        x_ext = zero_pad(x, ff_len-1, 'front');
        y_ext = zero_pad(y ,fb_len-1, 'front');
        % initialization - filter coefficients
        fcoef = zeros(ff_len + fb_len, length(x) - ff_len + 2);
        for ii = 1 : length(x) - ff_len + 1
            xx = [x_ext((1 : ff_len) + (ii - 1)); y_ext((1 : fb_len) + (ii - 1))];
            y(ii) = xx.' * fcoef(:, ii);
            if isnan(ts(ii)); target = slicer(y(ii), mf2mn(mf)); else target = ts(ii); end
            y_ext(fb_len + ii) = target;
            fcoef(:, ii + 1) = fcoef(:, ii) - gain * (y(ii) - target) * conj(xx) ./ (abs(xx) + eps);
        end
    otherwise
        warning('unknown modulation format'); keyboard;
end

function N = pmd_matrix(tau, rho)
% Polarization-mode dispersion N matrix including both phase and amplitude
% dispersion effects. The Jones matrix for PMD is given by the matrix exponential
%   J(\omega) = expm(N).
% Alternatively, if rho is a zero vector, the Jones matrix for PMD can be
% expanded into 
%   J(\omega) = cos(\omega t/2)*eye(2) + sin(\omega t/2)/(t/2)*N.
%----------------------------------------------------------------------------
if ~isreal(tau) || ~isreal(rho)
    warning('input parameter must be real'); keyboard;
end
N = [rho(1) + 1i*tau(1), tau(3) + rho(2) + 1i*tau(2) - 1i*rho(3);...
     rho(2) - tau(3) + 1i*tau(2) + 1i*rho(3), -rho(1) - 1i*tau(1)];
N = 0.5*N;
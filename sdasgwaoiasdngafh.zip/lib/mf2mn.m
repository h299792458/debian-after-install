function mn = mf2mn(mf)
% MN2MF Convert input number of constellation points to name of modulation
% format
%----------------------------------------------------------------------------
% Syntax: mn = mf2mn(mf)
% 
% See also: mn2mf
%----------------------------------------------------------------------------
switch mf
    case 'ASK'
        mn = 1;
    case 'BPSK'
        mn = 2;
    case 'QPSK'
        mn = 4;
    case '8PSK'
        mn = 8;
    case '16QAM'
        mn = 16;
    case '32QAM'
        mn = 32;
    case '64QAM'
        mn = 64;
    case '128QAM'
        mn = 128;
    case '256QAM'
        mn = 256;
    case '512QAM'
        mn = 512;
    case '1024QAM'
        mn = 1024;
    otherwise
        keyboard;
end

function v = evm(x, mn)
% EVM Get error vector magnitude for input mQAM signals
%----------------------------------------------------------------------------
% Syntax: v = evm(x, mn)
%
% Note: EVM will normalize the input mQAM signal first, followed by hard
%       slicer. Then the evm is calculated.
%----------------------------------------------------------------------------
xn = normalization(x, mn);
xd = slicer_mqam(xn, mn);
ps = mean(abs(xd).^2);
cc = constellation(mn);

for ii = 1 : mn
    idx{ii} = find(xd == cc(ii));
    n(ii) = mean(abs(xn(idx{ii}) - cc(ii)).^2);
end

v = mean(n) / ps;
% v = sqrt(v);


function bw = enbw(window, fs, domain)
% ENBW   Equivalent noise bandwidth
%----------------------------------------------------------------------------
%   BW = ENBW(WINDOW) returns the two-sided equivalent noise bandwidth for
%   a uniformly sampled window whose coefficients are specified in the
%   vector WINDOW. This bandwidth is normalized to the noise power per
%   frequency bin.
%
%   BW = ENBW(WINDOW, Fs) returns the two-sided equivalent noise bandwidth
%   (in Hz) for a uniformly sampled window whose coefficients are specified
%   in the vector WINDOW, where Fs is the sampling rate of the window.
%
%   % Example 1:
%   %   Compute the equivalent noise bandwidth of a Hann window
%   bw1 = enbw(hann(10000))
%
%   % Example 2:
%   %   Compute the equivalent noise bandwidth (in Hz) of a Hann window
%   %   sampled at 44.1 kHz.
%   bw2 = enbw(hann(10000), 44.1e3)

%   Reference:
%     [1] fredric j. harris [sic], On the Use of Windows for Harmonic
%         Analysis with the Discrete Fourier Transform, Proceedings of
%         the IEEE, Vol. 66, No. 1, January 1978.  Eqn 11, 15.
%----------------------------------------------------------------------------
switch domain
    case 'time'
        bw = (calcrms(window) / mean(window)).^2;
    case 'freq'
        bw = calcrms(window).^2 / abs(window(1)).^2 * length(window);
    otherwise
        keyboard;
end
bw = bw * double(fs) / length(window);

function cc

clc
close all


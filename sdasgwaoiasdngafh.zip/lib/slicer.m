function [symbol, ndx] = slicer(x, mn)
% SLICER Slice columns of input data into mQAM symbols
%----------------------------------------------------------------------------
% Syntax: [symbol, ndx] = slicer(x, mn)
% 
% Notes: [#] SLICER will normalize the input first. 
%        [#] The first output will be the mqam symbols with hard decision
%        [#] The second output is the decimal index indicating the symbols in
%            the constellation from topleft to bottomright in columns.
% 
% Tests: [~, ndx] = slicer(constellation(4), 4)
%        [~, ndx] = slicer(constellation(16), 16)
%        [~, ndx] = slicer(constellation(64), 64)
% 
% Examples: [~, ndx] = slicer(constellation(N), N) should return ndx = 1:N 
% 
% See also: qamdemod
%----------------------------------------------------------------------------
assert(iscolumn(x), 'column vector input required');
xnorm = normalization(x, mn);
% MSB first
switch mn 
    case 2
        bit = (real(xnorm) > 0);
	case 4
		bit = [(real(xnorm) > 0), ~(imag(xnorm) > 0)];
        
    case 8
        % todo
	case 16
		bound = 2;
		bit = [msign(real(xnorm)), ...
            msign(real(xnorm) - ksign(real(xnorm)) * bound), ...
			~msign(imag(xnorm)), ...
            ~msign(imag(xnorm) - ksign(imag(xnorm)) * bound)];
        
    case 32
        % todo
    % ---------------------------------------------------------------
    % 64qam slicing is combination of qpsk and 16qam slicing, i.e.
    % [4qam 16qam 16qam 4qam 16qam 16qam]
    % ---------------------------------------------------------------
	case 64 
		bound = 2;
		% this is the 4qam header
		bit1 = [msign(real(xnorm)), ~msign(imag(xnorm))];
		% convert 64qam symbol in one quater to 16qam
		x16 = xnorm - (ksign(real(xnorm)) * 4 + ksign(imag(xnorm)) * 4i);
		% slicing 16qam
		bit2 = [msign(real(x16)), msign(real(x16) - ksign(real(x16)) * bound),...
			~msign(imag(x16)), ~msign(imag(x16) - ksign(imag(x16)) * bound)];
		bit = [bit1(:, 1), bit2(:, 1:2), bit1(:, 2), bit2(:, 3:4)];
	case 256
		% todo
    otherwise
        warning('slicer::modulation format'); keyboard;
end

% convert bit in rows to dec by MSB to LSB order
twos = 2 .^ (log2(mn) - 1 : -1 : 0);
twos = ones(length(xnorm), 1) * twos;

% index of symbols from topleft to bottomright by columns
ndx = sum(bit.*twos, 2) + 1;

% symbols from topleft to bottomright by columns
c = constellation(mn);
symbol = c(ndx);


% return 1 if x > 0 and 0 if x <= 0
function s = msign(x)
s = (x > 0);


% return 1 if x > 0 and -1 if x <= 0
function s = ksign(x)
s = (x > 0) * 2 - 1;


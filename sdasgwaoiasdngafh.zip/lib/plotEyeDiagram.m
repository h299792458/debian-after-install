function h = plotEyeDiagram(x, period, xmod)
% PLOTEYEDIAGRAM Plot eye diagram of input data
%----------------------------------------------------------------------------
% Syntax:  = plotEyeDiagram(x, period, xmod)
% 
% Inputs: period - number of samples per eye
% 
% Note; The fancy one...
% h = commscope.eyediagram(...
%     'SamplingFrequency', samplingRate, ...
%     'SamplesPerSymbol', sps * upfactor, ...
%     'MinimumAmplitude', 0, ...
%     'MaximumAmplitude', 1, ...
%     'PlotType', '2D Color', ...
%     'ColorScale', 'log', ...
%     'RefreshPlot', 'on');
%----------------------------------------------------------------------------

if isrow(x), x = x.'; end

% get rid of extra data
tmp = mod(length(x), period);
xds = x(1 : end - tmp);
xrs = reshape(xds, period, []);

switch xmod
    case 'o'
        h = figure; 
        plot(0 : period - 1, abs(xrs).^2, 'Color', color_table(1)); grid on
        xlim([0, period]);
    case 'e'
        if isreal(x)
            h = figure; 
            plot(0 : period - 1, xrs, 'Color', color_table(1)); grid on
            xlim([0, period]);
        else
            h = figure;
            subplot(211); plot(0 : period - 1, real(xrs), 'Color', color_table(1)); grid on; xlim([0, period]);
            subplot(212); plot(0 : period - 1, imag(xrs), 'Color', color_table(1)); grid on; xlim([0, period]);
        end
    otherwise
        warning('unknown data mode'); keyboard;
end

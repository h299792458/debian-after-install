function pci = statbinoci(x, n, alpha)
% STATBINOCI Confidence interval for binomial p parameter.
%--------------------------------------------------------------------
%   Copyright 2008 The MathWorks, Inc.
%--------------------------------------------------------------------
% Lower limits
nu1 = 2*x;
nu2 = 2*(n-x+1);
F   = finv(alpha/2, nu1, nu2);
lb  = (nu1.*F)./(nu2 + nu1.*F);
% Fix NaNs caused by x=0
lb(x == 0) = 0;
% Upper limits
nu1 = 2*(x+1);
nu2 = 2*(n-x);
F   = finv(1-alpha/2, nu1, nu2);
ub  = (nu1.*F)./(nu2 + nu1.*F);
% Fix NaNs caused by x=n
ub(x == n) = 1;
pci = [lb(:), ub(:)];

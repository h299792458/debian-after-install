function photocurrent = photoDetectorSE(Ex, responsivity)
% ---------------------------------------------------------------------------
% Example: photocurrent = photoDetectorSE(Ex, responsivity)
% 
% Input: 
% 
% Reference: 
% ---------------------------------------------------------------------------

photocurrent = responsivity .* abs(Ex).^2;

% todo

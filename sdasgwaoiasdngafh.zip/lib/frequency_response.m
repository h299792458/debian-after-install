function H = frequency_response(nsample, fs, order, bandwidth, type)
% FREQUENCY_RESPONSE Calculate the frequency response of digital filter
% with input order and 3dB bandwidth
%----------------------------------------------------------------------------
% Syntax: H = frequency_response(nsample, fs, order, bandwidth, type)
%
% Inputs: nsample   - number of samples
%         fs        - sampling frequency [Hz]
%         order     - filter order/roll-off factor
%         bandwidth - filter 3dB bandwidth one-sided/baudrate [Hz]
%         type      - filter type
%
% Refs: [1] Martin Pfennigbauer, et al, "Choice of MUX/DEMUX filter
%           characteristics for NRZ RZ and CSRZ...", JLT, 2006.
%
% Note: PSD = H.^2
%----------------------------------------------------------------------------

if order < 0, warning('negative filter order'); keyboard; end

freq = get_fft_grid(nsample, fs);

switch lower(type)
    case 'bessel'
        % up to 6th order
        alpha = [1.0, 1.361654129, 1.755672389, ...
            2.113917675, 2.427410702, 2.703395061 ];
        
        % Laplace transformation
        s = 1i * freq / bandwidth * alpha(order);
        n = order;
        for k = 0 : n
            b(k+1) = factorial(2*n - k) / (2^(n - k) * factorial(k) * factorial(n - k));
            D(k+1, :) = b(k+1) * s.^k;
        end
        
        % numerator/denominator
        H = D(1,:) ./ sum(D);
        
        % Remove group delay
        ndxFreq = find(freq >= 0 & freq < bandwidth / alpha(order));
        pp = polyfit(freq(ndxFreq) / 1e9, unwrap(angle(H(ndxFreq))), 1);
        H = H .* exp(-1i * polyval(pp, freq/1e9));
        
        % normalize
        H = H / abs(H(1));
        
    case 'gaussian'        
        H = exp(-0.5 * log(2) * (freq / bandwidth) .^ (2 * order));
        
    case 'rc'
        freq = get_fft_grid_pos(nsample, fs);
        
        % if the number of samples is even, add one more frequency point
        if ~mod(nsample, 2), freq = [freq, freq(end) + fs/nsample]; end
        
        H = zeros(size(freq)) + eps;
        f_low = (1 - order) * 0.5 * bandwidth;
        f_high = (1 + order) * 0.5 * bandwidth;
        
        fndxl = find(freq <= f_low);
        fndxm = find(freq > f_low & freq <= f_high);
        
        H(fndxl) = ones(size(fndxl));
        H(fndxm) = 0.5 * (1 + cos(pi / order * (freq(fndxm) / bandwidth - 0.5 * (1 - order))));
        
        H = [H(1 : end - 1 + mod(nsample, 2)), conj(fliplr(H(2 : end)))];
        
    case 'rrc'
        H = sqrt(frequency_response(nsample, fs, order, bandwidth, 'rc'));
        
    case 'nyquist'
        H = frequency_response(nsample, fs, order, bandwidth, 'rc');
        
        f_high = (1 + order) * 0.5 * bandwidth;
        
        HSINC = ones(size(H));
        HSINC(abs(freq) <= f_high) = sinc(freq(abs(freq) <= f_high) ./ bandwidth);
        
        H = H ./ HSINC;
        
    case 'rect'
        H = zeros(size(freq)) + eps;
        H(abs(freq) <= bandwidth) = 1;
        
    otherwise
        keyboard;
end

H = H(:);
% normalize the filter response in frequency to unit energy
H = H./sqrt(sum(H.^2)/numel(H)); 

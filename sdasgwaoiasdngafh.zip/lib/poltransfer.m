function [x, y] = poltransfer(u, h, v)
% Apply polarization transfer matrix to input polarzations
%----------------------------------------------------------------------------
x = u(1,1).* h + u(1,2).* v;
y = u(2,1).* h + u(2,2).* v;

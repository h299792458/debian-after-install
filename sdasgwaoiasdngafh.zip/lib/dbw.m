function y = dbw(x)
% DBW Convert linear input to dB output
% ---------------------------------------------------------------------------
% Syntax: y = dbw(x)
% 
% See also: dbm, idbw, idbm
% ---------------------------------------------------------------------------
y = 10 * log10(x);

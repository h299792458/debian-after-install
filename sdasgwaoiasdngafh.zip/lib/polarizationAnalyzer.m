function [h] = polarizationAnalyzer(ex, ey, varargin)
% Polarization analyzer
%----------------------------------------------------------------------------
% Plot SOP as a function of frequency on a Poincare sphere. At any single
% frequency, the signal is completely polarized. 
% 
% Syntax: [h] = polarizationAnalyzer(ex,ey,varargin)
% 
% Inputs: ex - must be in row
%         ey - must be in row
% 
% Notes: Input field can be either time or freq domain
% 
% See also: spectrumAnalyzer
%----------------------------------------------------------------------------

s = jones2stokes(ex, ey);
h = poincare_sphere();
plot3(s(1,:), s(2,:), s(3,:), varargin{:});

function D = pdl_matrix(pdl)
% Get the pdl matrix
%----------------------------------------------------------------------------
rho = (pdl - 1) / (pdl + 1);
D(1,1) = sqrt(1 - rho);
D(2,2) = sqrt(1 + rho);
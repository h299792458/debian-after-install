function snr = osnr2snr(osnr, rs, dmod)
% OSNR2SNR Convert OSNR in 0.1nm (12.5GHz) in dB to SNR in dB
%----------------------------------------------------------------------------
% Syntax: snr = osnr2snr(osnr, rs, dmod)
% 
% Inputs: osnr - osnr in dB
%         rs   - symbol rate
%         dmod - data mode, complex or real
%----------------------------------------------------------------------------
switch lower(dmod)
    case 'complex'
        snr = osnr - 10*log10(rs/12.5e9);
    case 'real'
        snr = osnr - 10*log10(rs/12.5e9) + 10*log10(2);
    otherwise
        warning('unknown date mode'); keyboard;
end

function [ber, interval] = berconfint(nerr, ntrial, level)
% BERCONFINT BER and confidence interval of Monte Carlo simulation.
%--------------------------------------------------------------------
%   [BER INTERVAL] = BERCONFINT(NERRS, NTRIALS) returns the error
%   probability BER and the confidence interval INTERVAL with 95%
%   confidence for a Monte Carlo simulation of NTRIALS trials with NERRS
%   errors.
%
%   [BER INTERVAL] = BERCONFINT(NERRS, NTRIALS, LEVEL) returns the error
%   probability BER and the confidence interval INTERVAL with confidence
%   level LEVEL for a Monte Carlo simulation of NTRIALS trials with NERRS
%   errors.
% 
%   See also BINOFIT, MLE (both in Statistics and Machine Learning Toolbox).
% 
%   Copyright 1996-2014 The MathWorks, Inc.
%--------------------------------------------------------------------
if nargin < 3, level = 0.95; end
if ~isfloat(nerr), nerr = double(nerr); end
ber = nerr./ntrial;
interval = statbinoci(nerr, ntrial, 1-level);

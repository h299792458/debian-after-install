function freq = get_fft_grid(n, fs)
% GET_FFT_GRID Get two-sided zero-first frequency grid vector for FFT
% ---------------------------------------------------------------------------
% Syntax: freq = get_fft_grid(nsample, fs)
% 
% Notes: For even and odd number of samples, the frequency vector always
%       centers at zero. Even number of samples gets one extra point at the
%       negative end.
% ---------------------------------------------------------------------------
if mod(n, 2)
    freq = [(0:1:(n-1)/2), (-(n-1)/2:1:-1)]' * fs / n;
else
    freq = [(0:1:n/2 - 1), (-n/2:1:-1)]' * fs / n;
end


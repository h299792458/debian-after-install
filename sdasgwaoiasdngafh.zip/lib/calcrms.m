function y = calcrms(x, dim)
% CALCRMS Calculate the root-mean-squared value of input
%--------------------------------------------------------------------
% Syntax: y = calcrms(x, dim)
%--------------------------------------------------------------------
if nargin==1
  y = sqrt(mean(x .* conj(x)));
else
  y = sqrt(mean(x .* conj(x), dim));
end

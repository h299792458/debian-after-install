function ccc

clc
close all
clear

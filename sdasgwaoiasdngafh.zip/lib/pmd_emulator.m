function [x, y] = pmd_emulator(h, v, freq, tau, rho)
% First-order PMD emulator realized in frequency domain with the common
% phase negnected.
%----------------------------------------------------------------------------
% Note that without amplitude dispersion and the common phase, the Jones
% matrix belongs to the special unitary group SU(2) and, therefore, has 3
% degrees of freedom. The sinc is used to account for zero DGD.
%----------------------------------------------------------------------------
% get the dispersion matrix
N   = 2 * pmd_matrix(tau, rho);
dgd = norm(tau);
% calculate the first order pmd jones matrix
J_1 = sinc(freq*dgd)*pi.*freq * N(1) + cos(pi*freq*dgd);
J_2 = sinc(freq*dgd)*pi.*freq * N(2);
J_3 = sinc(freq*dgd)*pi.*freq * N(3);
J_4 = sinc(freq*dgd)*pi.*freq * N(4) + cos(pi*freq*dgd);
% apply the pmd matrix in frequency domain
x = ifft(J_1.*fft(h) + J_3.*fft(v));
y = ifft(J_2.*fft(h) + J_4.*fft(v));
function [newstate] = fifo_buffer(state, data)
% FIFO_BUFFER buffering row data in fifo
%----------------------------------------------------------------------------
% Syntax: [newstate] = fifo_buffer(state, data)
% 
% Inputs: state - current buffer
%         data  - data for buffering
%----------------------------------------------------------------------------

% this is number of columns, i.e. the data length
ncol = size(data, 2);
if ncol > size(state,2)
    warning('data length larger than buffer length, lossing data');
    ncol = size(state,2);
end

% fifo
newstate = [state(:, ncol+1:end), data(:, 1:ncol)];


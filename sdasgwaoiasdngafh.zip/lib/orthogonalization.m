function [U] = orthogonalization(V)
% ORTHOGONALIZATION The stabilized Gram–Schmidt orthonormalization. The
% columns of matrix V are replaced by orthonormal vectors (columns of U)
% which span the same subspace
%----------------------------------------------------------------------------
% Classic Gram-Schmidt process:
% uk = vk - proj_of_vk_on_u1 - proj_of_vk_on_u2 - ... -
% proj_of_vk_on_u(k-1)
%
% Modified (stablized) Gram-Schmidt process computes each perpendicular
% component iteratively so that each perpendicular component is orthogonal
% to any error introduced in each step:
% 1st: uk = vk - proj_of_vk_on_u1;
% 2nd: uk = uk - proj_of_uk_on_u2;
% ....
%
% Example:
%   Input V = [1 1; 0 1] representing a linear transformation of sheering y
%   axis and U = orthGramSchmidt(V) outputs orthonormal basis U = [1 0; 0 1]
%
% Note that the Gram-Schmitdt process always takes the 1st column of input
% as a start point to construct an orthonormal basis such that it could
% result in an rotated orthonormal basis
% 
% We have vector {r1,r2} and the angle between them is pi/2-theta, now,
% build two orthogonal vectors from {r1,r2}:
% r1' = r1
% r2' = r2 - <r1r2>/<r1^2>*r1'
%----------------------------------------------------------------------------
% for k = 1 : size(x, 2)
%     r1 = real(x(:, k));
%     r2 = imag(x(:, k));
%     sin2theta = mean(r1 .* r2) / mean(r1.^2);
%     r4 = (r2 - r1 * sin2theta) / sqrt(1 - sin2theta^2);
%     y(:, k) = r1 + 1i * r4;
% end
% theta = asin(sin2theta) / pi * 180;
n = size(V,1);
k = size(V,2);
U = zeros(n,k);
U(:,1) = V(:,1) / sqrt(V(:,1)' * V(:,1));
for i = 2 : k
    U(:,i) = V(:,i);
    for j = 1 : i-1
        U(:,i) = U(:,i) - (U(:,i)' * U(:,j)) * U(:,j);
    end
    U(:,i) = U(:,i) / sqrt(U(:,i)' * U(:,i));
end

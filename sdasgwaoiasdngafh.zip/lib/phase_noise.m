function pn = phase_noise(nsample, pvar, pini)
% PHASE_NOISE Generate random walk discrete phase noise
%----------------------------------------------------------------------------
% Syntax: pn = phase_noise(nsample, pvar, pini)
% 
% Inputs: pvar - variance of phase step modeled as zero-mean WGN.
%         pini - uniform distributed initial phase in the interval [0, 2*pi], 
%                0 by default.
% 
% Notes: Random walk phase noise can be considered as integration of WGN
%       frequency noise. The WGN is AC filtered and normalized first.
% 
% Phase noise can be considered as a type of *red* noise with Lorentzian
% power spectrul density. The general model of phase noise is the Wiener
% process, i.e., integration of frequency noise which is often modeled as
% WGN. In this simplest case, the variance of white frequency noise is
% given by
% 
% pvar = 2 * pi * LW * T
% 
% where LW is the FWHM of the Lorentzian lineshape, i.e., the linewidth. T
% is the sampling interval. Note that the frequency noise is governed by
% quantum effect and will not go to zero. Therefore, every oscillator has
% its *intrinsic* linewidth which cannot be made arbitrarily small. Treat
% the phase at one time instance as a variable, it is easy to show that it
% is gaussian with zero mean and increasing vaiance proportional to the
% time index. Also, the phase difference between two time instances t1 and
% t2 is also a gaussian variable with zero mean and variance proportional
% to the time difference. Therefore, faster sampling will experience slower
% phase changes. In the symbol domain, the signal will have lower excess
% noise induced by phase variation.
% 
% See also: gaussian_noise
%----------------------------------------------------------------------------
if nargin < 3, pini = 0; end

% WGN frequency noise scaled with 2*pi*T
tmp = randn(1, nsample);

% remove dc component followed by normalization
tmp = tmp - mean(tmp);
tmp = tmp / calcrms(tmp);

% integration
pn = pini + cumsum(tmp .* sqrt(pvar));

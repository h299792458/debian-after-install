function y = timing_error_detector(px, alg)
% TIMING_ERROR_DETECTOR Timing error detectors
%----------------------------------------------------------------------------
% Syntax: y = timing_error_detector(px, alg)
% 
% Inputs: alg - 'AVN', 'SLN', 'FLN', 'LOGN', 'SLN_ITP', 'DTP', 'Gardner',
%               'Godard', ...
% 
% Spectral-line methods for symbol synchronization based on nonlinear
% operation of the input symbols include AVN, SLN, FLN, LOGN, applicable
% for feedforward symbol synchronization.
% 
% Spectral-correlation methods for symbol synchronization based on
% spectrum autocorrelation include DTP, SLN, LEE, GARDNER, GODARD,
% applicable for feedback symbol synchronization.
%----------------------------------------------------------------------------

assert(iscolumn(px), 'column vector input required');
k = 1 : length(px);

% exponant of DFT at pi/2
ex = exp(-1i .* (k - 1)' .* pi ./ 2);

if strcmpi(alg, 'AVN')
    s = -conj(sum(abs(px) .* ex));
    y = -angle(s) / 2 / pi;
elseif strcmpi(alg, 'SLN')
    s = -conj(sum(abs(px).^2 .* ex));
    y = -angle(s) / 2 / pi;
elseif strcmpi(alg, 'SLN_itp')
    N = length(px);
    x = interpft(px, 2*N);
    k = 1 : 2*N;
    ex = exp(-1i .* (k - 1)' .* pi ./ 2);
    s = -conj(sum(abs(x).^2 .* ex));
    y = -angle(s) / 2 / pi;
elseif strcmpi(alg, 'FLN')
    s = -conj(sum(abs(px).^4 .* ex));
    y = -angle(s) / 2 / pi;
elseif strcmpi(alg, 'LOGN')
    s = -conj(sum(log(1 + 10.*abs(px).^2) .* ex));
    y = -angle(s) / 2 / pi;
elseif strcmpi(alg, 'LEE')
    g = 1.414;
    n = 1 : length(px);
    ex1 = (-1).^(n - 1);
    sum_1 = sum(abs(px).^2 .* ex1.');
    ex2 = 1j * (-1).^(n-1);
    xh = px(2 : end);
    xx = px(1 : end - 1);
    ex2 = ex2(1 : end - 1);
    sum_2 = sum(real(conj(xx) .* xh) .* ex2.');
    s = -(g * sum_1 + sum_2);
    y = -angle(s) / 2 / pi;
elseif strcmpi(alg, 'DTP')
    x = abs(px(1 : 2 : end - 1)) .^ 2;
    y = abs(px(2 : 2 : end)) .^ 2;
    y = mean((y - x) ./ sqrt(2));
elseif strcmpi(alg, 'Gardner')
    px1 = px(1 : 2 : end - 2);
    px2 = px(2 : 2 : end - 1);
    px3 = px(3 : 2 : end);
    y = mean((real(px1) - real(px3)) .* real(px2) ...
        + (imag(px1) - imag(px3)) .* imag(px2));
elseif strcmpi(alg, 'Godard')
    nfft = 2^nextpow2(length(px));
    yy = fft(px, nfft);    
    % sum over half of spectrum
    xc = xcorr(yy);
    % in Godard's original paper
    y = -imag(xc(nfft / 2)) / nfft;
else
    warning('unknown algorithm'); keyboard;
end


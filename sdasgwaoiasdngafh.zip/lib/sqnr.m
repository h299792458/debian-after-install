function ssss = sqnr(enob)
% SQNR Signal-to-quantization-noise ratio
%----------------------------------------------------------------------------
% Calculate the signal-to-quantization-noise ratio based on the input
% effective number of bits. The harmonic distortion is considered
% effectively as part of quantization noise. The signal amplitude is
% assumed occupying the full scale of ADC.
% 
% Syntax: SSSS = SQNR(ENOB)
% Inputs: ENOB - effective number of bits
% Output: SSSS - SQNR in dB scale
% 
% Note that the signal power is within signal's bandwidth whereas the
% quantization noise power is within the entire Nyquist bandwidth, i.e., 0
% ~ fs/2. Therefore, the ratio between these two bandwidth, i.e. processing
% gain, has to be included in the actual SNR of signal.
%----------------------------------------------------------------------------
ssss = 10*log10(1.5) + enob * 10*log10(4);

function [M, U] = sop_rotate(J, az, ep)
% Rotate the sop of input jones vector in stokes space, where 2*az and 2*ep
% denotes the longitude and latitude, respectively. In order to cover every
% sop on the sphere, first, the initial sop is rotated around axis s3 by
% angle of 2*az, then the resulting sop is shifted along the latitude-line
% to s2-s3 plane, where a linear birefringence is applied to move the sop
% along the longitude-line to latitude of 2*ep, finally the sop is shifted
% back to its original longitude to complete the move. Note that the
% effective range of az is plus/minus pi/2, whereas ep is plus minus pi/4.
%----------------------------------------------------------------------------
% TEST PROGRAM: test(1)
%----------------------------------------------------------------------------
L = [cos(az), -sin(az); sin(az), cos(az)];
J = L * J;
s = jones2stokes(J(1), J(2));
if s(1)<0 && s(2)>0
    a2 = atan(s(2)/s(1)) + pi;
elseif s(1)<0 && s(2)<0
    a2 = atan(s(2)/s(1)) - pi;
else
    a2 = atan(s(2)/s(1));
end
% overwrite az in special cases
if s(1)==0 && s(2)==0, a2 = 0; end
% 2a represents the angle to shift along the latitude to the s2-s3 plane
a = 0.5 * (pi/2 - a2);
% circular birefringence represented by a simple rotation matrix, tracing
% out a circle parallel to s1-s2 plane
R = [cos(a), -sin(a); sin(a), cos(a)]; 
% linear birefringence represented by phase retardation, tracing out a
% circle parallel to s2-s3 plane
D = [exp(-1i*ep), 0; 0, exp(1i*ep)]; 
S = [cos(a), sin(a); -sin(a), cos(a)];

M = S * D * R * J;
U = S * D * R * L;

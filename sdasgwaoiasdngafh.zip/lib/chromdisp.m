function [H] = chromdisp(nsample, fs, lambda, lambda0, DL, SL)
% CHROMDISP Chromatic dispersion
%----------------------------------------------------------------------------
% Return frequency response of optical chromatic dispersion with
% accumulated dispersion and dispersion slop.
% 
% Syntax: [H] = chromdisp(nsample, fs, lambda, lambda0, DL, SL)
% 
% Inputs: nsample     - number of samples
%         fs          - sampling frequency [Hz]
%         lambda      - center wavelength of optical signal
%         lambda0     - center wavelength of global simulation
%         DL          - accumulated linear dispersion at lambda0 [s/m]
%         SL          - acuumulated dispersion slop at lambda0 [s2/m]
% 
% Refs: []
% 
% Note: The higher-order effects are only needed for ultra-high bandwidth
% 
% See also: 
%---------------------------------------------------------------------------- 
c = 299792458;
freq = get_fft_grid(nsample, fs);
DL = DL + (lambda - lambda0) * SL;
phi = lambda.^2 * DL * pi / c * freq.^2 ...
    - (lambda.^3 * DL * 2 + lambda.^4 * SL) * pi / 3 / c^2 * freq.^3;
H = exp(1i * phi);
H = H(:);

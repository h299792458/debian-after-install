function snr = ber2snr(ber, k, snrmode)
% BER2SNR Calculate required SNR for a given BER with mQAM in the AWGN
% channel
% ---------------------------------------------------------------------------
% Syntax: snr = ber2snr(ber, k, snrmode)
% 
% Inputs: ber - vector, Required BER
%         k   - scalar, number of bits per symbol
%     snrmode - string, mode of output SNR, e.g 'dB', 'linear'
% 
% Algs: ber = 1 - sqrt(ser);
%       ser = erfc(sqrt(snr/2)) - (1/4)erfc^2(sqrt(snr/2));
%
% Note: erfc = 1 - erf
%       erfinv(erf(x)) = x
%
% Test: ber2snr(snr2ber(1.5, 2, 'db'), 2, 'db')
%
% See also: snr2ber
% ---------------------------------------------------------------------------
if k == 1
    snr = 2 * (erfinv(1 - 2*ber)) .^ 2;
elseif k == 2
    snr = 2 * (erfinv(1 - 2*ber)) .^ 2;
else
    % todo: may use interpolation
end

switch lower(snrmode)
    case 'db'
        snr = 10 * log10(snr);
    case 'linear'
        % do nothing 
    otherwise, warning('ber::snr mode'); keyboard;
end


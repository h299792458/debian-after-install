%===========================================================================
% Monte Carlo simulation of BER of mQAM signal in AWGN using one sample per
% symbol only, no pulse-shaping is considered in this version.
%===========================================================================
function ber = berawgn_montecarlo(k)
if nargin < 1, k = 1; end
ndata = 10^6;
refbit = randi([0 1], k, ndata);
tx = mqammod(refbit);
ps = calcrms(tx).^2;
snr = (-10 : .5 : 10)';
ber = zeros(length(snr), 1);
ber_ci = zeros(length(snr), 2);
for ndx = 1 : length(snr)
    pn = ps / idbw(snr(ndx));
    ww = gaussian_noise(size(tx,1), size(tx,2), pn, 'linear', 'complex');
    signal = tx + ww;
    bits = qamdemod(signal, 2^k);
    if k == 1, bits = bits.'; end
    ner(ndx) = sum(sum(abs(bits - refbit)));
    [ber(ndx), ber_ci(ndx, :)] = berconfint(ner(ndx), numel(bits), 0.95);
    fprintf('snr = %.1f, ber = %.4e\n', snr(ndx), ber(ndx));
end
% Theoretical BER in AWGN. Note that the input should be EbNo. For BPSK,
% SNR is doubled since only the real part of noise counts.
if k == 1
    ber_t = berawgn(snr + dbw(2) - dbw(2), 'psk', 2, 'nodiff');
else
    ber_t = berawgn(snr - dbw(k), 'qam', 2^k);
end
plot_ber_snr(snr, ber, ber_t, ber_ci);

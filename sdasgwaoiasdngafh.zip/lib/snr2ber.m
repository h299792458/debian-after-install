function ber = snr2ber(snr, k, snrmode)
% SNR2BER Calculate theoretical BER of Gray-coded square mQAM in AWGN
% channel
%----------------------------------------------------------------------------
% The complex modulated square mQAM signal can be considered as a
% 2-dimensional signal and the symbol error rate can be expressed as
% 
%    P_sym = 1 - (1 - P_i/q)^2 = 2 * P_i/q - (P_i/q)^2,
% 
% where P_i/q is the symbol error rate of each quadrature
% 
% Syntax: ber = snr2ber(snr, k, snrmode)
% 
% Inputs: snr - snr in one dimension; 
%         k   - bit-per-symbol;
% 
% Tests: snr2ber(ber2snr(4.56e-1, 2, 'db'), 2, 'db')
% 
% See also: ber2snr
%----------------------------------------------------------------------------

if nargin < 3, warning('snr mode required'); keyboard; end

M = 2.^k;
scalar = sqrt(1 / (2/3*(M-1)));

switch lower(snrmode)
    case 'db'
        snr = 10 .^ (0.1 * snr);
    case 'linear'
        % do nothing
    otherwise
        warning('snr mode required'); keyboard;
end

if k == 1 % bpsk
	esno = snr / 2;
else
	esno = snr;
end

ser_iq = (1 - 1/sqrt(M)) * erfc(scalar * sqrt(esno));
ser = 2 * ser_iq - ser_iq.^2;

if k == 1
    ber = 0.5 * erfc(sqrt(esno));
elseif k == 2
    ber = 1 - sqrt(1 - ser);
else % todo
    ber = ser / k;
end


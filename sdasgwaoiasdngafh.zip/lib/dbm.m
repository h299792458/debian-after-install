function y = dbm(x)
% DBM Convert linear input to dBm output
% ---------------------------------------------------------------------------
% Syntax: y = dbm(x)
% 
% See also: dbw, idbm, idbw
% ---------------------------------------------------------------------------
y = 10 * log10(x) + 30;

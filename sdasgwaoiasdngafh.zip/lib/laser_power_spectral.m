function L = laser_power_spectral(nvar, freq)
% LASER_POWER_SPECTRAL Lorentzian laser power spectral density
%----------------------------------------------------------------------------
% Syntax: L = laser_power_spectral(nvar, freq)
% 
% Inputs: nvar - two-sided noise power spectral density of angular frequency noise
%         freq - frequency range
% 
% See also: phase_noise
%----------------------------------------------------------------------------
L = 4 * nvar / (nvar.^2 + 16 .* pi^2 .* freq.^2);
L = L(:);

function [new_x] = zero_pad(x, zp_length, mode)
% ZERO_PAD Zero-pad the input data in columns
%----------------------------------------------------------------------------
% Syntax: [new_x] = zero_pad(x, zp_length, mode)
%
% Inputs: x         - column vector, input data
%         zp_length - scalar, zero-padding length
%         mode      - string, 'front' or 'end'
% 
% Note that the built-in fft includes zeropadding already. But this routine
% also support zeropadding in the front of incoming data.
% Note that this routine doesn't check the formation of input. But the
% input data should be in columns in general.
% 
% See also: fft
%----------------------------------------------------------------------------
if strcmpi(mode, 'front')
    new_x = [zeros(zp_length, size(x,2)); x];
elseif strcmpi(mode, 'end')
    new_x = [x; zeros(zp_length, size(x,2))];
else
    keyboard;
end


function esno = osnr2esno(osnr,rs)
% OSNR2ESNO Convert OSNR in 0.1nm (12.5GHz) in dB to EsNo in dB
%---------------------------------------------------------------------------
% Syntax: esno = osnr2esno(osnr,rs)
% 
% See also: osnr2snr
%---------------------------------------------------------------------------
esno = osnr - 10*log10(rs/12.5e9);

function angleInRadians = deg2rad(angleInDegrees)
% DEG2RAD Convert angles from degrees to radians
% ---------------------------------------------------------------------------
%   angleInRadians = DEG2RAD(angleInDegrees) converts angle units from
%   degrees to radians.
% ---------------------------------------------------------------------------
angleInRadians = (pi/180) * angleInDegrees;

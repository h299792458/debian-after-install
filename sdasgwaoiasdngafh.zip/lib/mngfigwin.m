function mngfigwin(h1, h2)
% MNGFIGWIN Manage position of 2 figures in the mode configured left-right side by
% side
%---------------------------------------------------------------------------- 
% Syntax: mngfigwin(h1, h2)
%----------------------------------------------------------------------------
scrsz = get(0,'ScreenSize');
screen_width = scrsz(3);

p1 = get(h1,'Position');
p2 = get(h2,'Position');

p1(1) = round(screen_width / 2) - p1(3);
p2(1) = p1(1) + p1(3) + 6;
set(h1,'Position',p1);
set(h2,'Position',p2);

drawnow;

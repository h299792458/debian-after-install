function photocurrent = photoDetectorBN(Ep, En, Rp, Rn)
% ---------------------------------------------------------------------------
% Example: photocurrent = photoDetectorBN(Ep, En, Rp, Rn)
% 
% Input: 
% 
% Reference: 
% ---------------------------------------------------------------------------

photocurrent = Rp .* abs(Ep).^2 - Rn .* abs(En).^2;

% todo

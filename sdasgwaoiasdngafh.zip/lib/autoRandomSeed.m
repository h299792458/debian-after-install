function [] = autoRandomSeed(rnsd)
% Reset system random number seed automatically
% --------------------------------------------------------------------------- 
% Syntax: autoRandomSeed(seed)
% 
% Inputs: rnsd - seed
% ---------------------------------------------------------------------------
if rnsd
    rng(rnsd);
else
    rng_now = rng;
    tmp = randi([1,65534],1,1);
    while (tmp == rng_now.Seed)
        tmp = randi([1,65534],1,1);
    end
    rng(tmp);
end


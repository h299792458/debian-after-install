function [psd, freq] = spectrumAnalyzer(x, nfft, fs)
% SPECTRUMANALYZER Spectrum analyzer
%----------------------------------------------------------------------------
% Signal spectrum analyzer based on windowed periodogram with zeropadding.
% 
% Syntax: [psd, pxx, freq] = spectrumAnalyzer(x, nfft, fs)
%----------------------------------------------------------------------------
if nargin < 1, x = rand(1024,1); end
if nargin < 2, nfft = length(x); end
if nargin < 3, fs = 1.0;         end
if isempty(nfft), nfft = length(x); end
if isrow(x), x = x.'; end

psd  = periodogram(x, nfft);
freq = get_fft_grid(nfft, fs);
resl = (max(freq) - min(freq)) / (nfft - 1);

% the true power density should be
% pxx = psd / (fs / nfft);

if nargout == 0
    xx = fftshift(freq);
    yy = ones(size(psd));
    for ii = 1:size(psd,2)
        yy(:,ii) = fftshift(10*log10(psd(:,ii)));
    end
    fig = figure('unit', 'pixels', 'color', 'w');
    fig.CurrentAxes = axes;
    fig.OuterPosition = [300, 300, 800, 600];
    hh = plot(fig.CurrentAxes, xx, yy); grid on; box on;
    xlim([min(xx), -min(xx)]);
    ylim([-90, 10]);
    xlabel('Frequency (Hz)');
    ylabel('Power (dB)');
    title('Spectrum Analyzer');
    
    % add annotation
    if resl >= 1e9
        res_str = sprintf('%.2f GHZ', resl/1e9);
    elseif resl >= 1e6
        res_str = sprintf('%.2f MHZ', resl/1e6);
    elseif resl >= 1e3
        res_str = sprintf('%.2f KHZ', resl/1e3);
    else
        res_str = sprintf('%.2f HZ', resl);
    end
    if isreal(x), 
        dat_str = 'REAL';
    else
        dat_str = 'COMPLEX';
    end
    sepstr = '    ';
    anstr = ['DAT: ', dat_str, sepstr, ...
        'RES: ', res_str, sepstr, ...
        'NFFT: ', num2str(nfft), sepstr, ...
        'WIN: NON', sepstr, ...
        'TRACE: ', num2str(size(x,2)), sepstr, ...
        'POWER: ', num2str(sum(psd)), sepstr];
    annotation(fig, 'textbox', [0.16, 0.8, 0.1, 0.1], ...
        'String', anstr, ...
        'FitBoxToText', 'on', ...
        'BackgroundColor', 'green', ...
        'FaceAlpha', .2);
    
    % add uicontrol
    btn_toggle = uicontrol('Style', 'pushbutton', ...
        'String', 'Toggle',...
        'Position', [20 20 50 20],...
        'Callback', @toggle_axis);
    btn_rectwin = uicontrol('Style', 'pushbutton', ...
        'String', 'Rect',...
        'Position', [20 45 50 20],...
        'Callback', {@rect_win, x, nfft fs});
    btn_hannwin = uicontrol('Style', 'pushbutton', ...
        'String', 'Hann',...
        'Position', [20 70 50 20],...
        'Callback', {@hann_win, x, nfft fs});
    btn_chebwin = uicontrol('Style', 'pushbutton', ...
        'String', 'Cheb',...
        'Position', [20 95 50 20],...
        'Callback', {@cheb_win, x, nfft, fs});
end


function toggle_axis(uic, callbackdata)
xx = xlim(uic.Parent.CurrentAxes);
if xx(1) == 0
    xlim(uic.Parent.CurrentAxes, [-xx(2), xx(2)]);
else
    xlim(uic.Parent.CurrentAxes, [0, xx(2)]);
end


function rect_win(uic, callbackdata, x, nfft, fs)
freq = get_fft_grid(nfft, fs);
psd  = periodogram(x, nfft);
xx = fftshift(freq);
yy = ones(size(psd));
for ii = 1:size(psd,2)
    yy(:,ii) = fftshift(10*log10(psd(:,ii)));
end
hh = uic.Parent.CurrentAxes.Children;
for ii = 1 : length(hh)
    set(hh(end-ii+1), 'XData', xx, 'YData', yy(:,ii));
end


function hann_win(uic, callbackdata, x, nfft, fs)
freq = get_fft_grid(nfft, fs);
win = hann(length(x));
x = x .* ((win ./ calcrms(win)) * ones(1, size(x,2)));
psd = periodogram(x, nfft);
xx = fftshift(freq);
yy = ones(size(psd));
for ii = 1:size(psd,2)
    yy(:,ii) = fftshift(10*log10(psd(:,ii)));
end
hh = uic.Parent.CurrentAxes.Children;
for ii = 1 : length(hh)
    set(hh(end-ii+1), 'XData', xx, 'YData', yy(:,ii));
end


function cheb_win(uic, callbackdata, x, nfft, fs)
freq = get_fft_grid(nfft, fs);
win = chebwin(length(x));
x = x .* ((win ./ calcrms(win)) * ones(1, size(x,2)));
psd = periodogram(x, nfft);
xx = fftshift(freq);
yy = ones(size(psd));
for ii = 1:size(psd,2)
    yy(:,ii) = fftshift(10*log10(psd(:,ii)));
end
hh = uic.Parent.CurrentAxes.Children;
for ii = 1 : length(hh)
    set(hh(end-ii+1), 'XData', xx, 'YData', yy(:,ii));
end


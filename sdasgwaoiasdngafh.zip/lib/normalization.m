function y = normalization(x, mn)
% NORMALIZATION Normalize mQAM signal to its canonical form
%----------------------------------------------------------------------------
% See also: constellation
%----------------------------------------------------------------------------

scale_factor = getPowerFactorQAM(mn);

% first normalize signal to UNIT average symbol energy,
% then, multiply by scaling factor
y = x / sqrt(mean(abs(x).^2)) * sqrt(scale_factor);


%----------------------------------------------------------------------------
% get the scaling factor for canonical form, i.e., the average power of
% canonical form. Note that the scaling factor is 2/3*(mn-1) for square QAM
%----------------------------------------------------------------------------
function [p] = getPowerFactorQAM(M)
if M == 2
	p = 1;
elseif M == 8
	p = 10;
elseif M == 32
	p = 20;
else % for square mqam
	p = 2/3 * (M - 1); 
end


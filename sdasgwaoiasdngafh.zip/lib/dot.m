function x = dot(a, b)
% Vector dot product
%--------------------------------------------------------------------
% X = DOT(A,B) returns the scalar product of the vectors A and B. A and B
% must be vectors of the same length.  When A and B are both column
% vectors, DOT(A,B) is the same as A'*B.
%--------------------------------------------------------------------

if min(size(a))==1, a = a(:); end
if min(size(b))==1, b = b(:); end

x = sum(conj(a).*b);

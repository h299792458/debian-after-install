function R = rotation_matrix(angle)
% Get the ccw rotation matrix
%----------------------------------------------------------------------------
R = [cos(angle), -sin(angle); ...
     sin(angle),  cos(angle)];

function h = plot_ber_snr(snr, ber, ber_t, ber_ci)
h = figure;
plot(snr, log10(ber_t), '-', snr, log10(ber), 's-.'); hold on;
errorbar(snr, log10(ber), log10(ber_ci(:,1))-log10(ber), log10(ber_ci(:,2))-log10(ber)); grid on;
xlabel('SNR [dB]');
ylabel('BER [log]');
legend('Theory');
h.CurrentAxes.YScale = 'log';
if numel(snr) == 1
    xlim([snr-1, snr+1]);
else
    xlim([min(snr), max(snr)]);
end

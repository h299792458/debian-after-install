function mf = mn2mf(mn)
% MN2MF Convert input number of constellation points to name of modulation
% format
%----------------------------------------------------------------------------
% Syntax: mf = mn2mf(mn)
%----------------------------------------------------------------------------
switch mn
    case 1
        mf = 'ASK';
    case 2
        mf = 'BPSK';
    case 4
        mf = 'QPSK';
    case 8
        mf = '8PSK';
    case 16
        mf = '16QAM';
    case 32
        mf = '32QAM';
    case 64
        mf = '64QAM';
    case 128
        mf = '128QAM';
    case 256
        mf = '256QAM';
    case 512
        mf = '512QAM';
    case 1024
        mf = '1024QAM';
    otherwise
        keyboard;
end


function output = upsampling(input, sps, insert_zero)
% UPSAMPLING Upsampling signal via holding the sample value by default, or
% inserting zeros between samples
%----------------------------------------------------------------------------
% Syntax: upsampling(input, sps, insert_zero)
%         set 'insert_zero' to TRUE to insert zeros between samples
% 
% Note: The built-in 'upsample.m' is equivalent to set 'insert_zero' to true
% 
% See also: upsample, upfirdn
%----------------------------------------------------------------------------
assert(iscolumn(input), 'column vector input required');
temp = ones(sps, 1) * input.';
if insert_zero, temp(2 : end, :) = 0; end
output = temp(:);

function h = poincare_sphere()
% Plot a Poincar sphere
h = figure('visible', 'on', 'color', [.2 .2 .2]);
sphere
axis('equal', 'off')
colormap(gray)
shading interp
alpha(0.8)
view([135, 25])

hold on

plot3([0, 2], [0, 0], [0, 0], 'w-', 'linewidth', 1)
plot3([0, 0], [0, 2], [0, 0], 'w-', 'linewidth', 1)
plot3([0, 0], [0, 0], [0,1.5], 'w-', 'linewidth', 1)

theta_tmp = linspace(0, 2*pi, 60);
x_tmp = cos(theta_tmp);
y_tmp = sin(theta_tmp);
z_tmp = zeros(1, length(theta_tmp));
plot3(x_tmp, y_tmp, z_tmp, 'w-', 'linewidth', .5)

x_tmp = cos(theta_tmp);
y_tmp = zeros(1, length(theta_tmp));
z_tmp = sin(theta_tmp);
plot3(x_tmp, y_tmp, z_tmp, 'w-', 'linewidth', .5)

x_tmp = zeros(1, length(theta_tmp));
y_tmp = cos(theta_tmp);
z_tmp = sin(theta_tmp);
plot3(x_tmp, y_tmp, z_tmp, 'w-', 'linewidth', .5)

clear *tmp

text(2.1, 0, 0, 'S_1', 'Color', 'w', 'FontWeight', 'b', 'FontSize', 14)
text(0, 2.1, 0, 'S_2', 'Color', 'w', 'FontWeight', 'b', 'FontSize', 14)
text(0, 0, 1.6, 'S_3', 'Color', 'w', 'FontWeight', 'b', 'FontSize', 14)
function git(comments)
if nargin < 1, comments = 'some changes'; end
comments = ['"' comments '"'];
system('git add .');
fprintf('---- commit changes ----\n');
system(['git commit -m ', comments]);
fprintf('---- commit sucess ----\n');
system('git push');


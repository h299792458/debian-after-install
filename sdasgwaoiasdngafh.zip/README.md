# dsp3

Matlab code for simulating digital communication system, including transmitter and receiver side digital signal processing, channel modeling, and so on.



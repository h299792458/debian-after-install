function vm = go(vSet, LOG, VERBOSE, MODE, DSPMOD, DSPCRT)
%----------------------------------------------------------------------------
% Fiber-optics with DSP
% TODO random 1st-order pmd
% TODO 2nd-order pmd (frequency dependence of DGD and PSP)
%----------------------------------------------------------------------------
if nargin < 6, DSPCRT = 0; end
if nargin < 5, DSPMOD = 0; end
if nargin < 4, MODE = 0; end
if nargin < 3, VERBOSE = 1; end
if nargin < 2, LOG = 0; end
%----------------------------------------------------------------------------
if LOG
    log_file = fopen('log','a');
    fprintf(log_file, '-------------------------------------\n');
    fprintf(log_file, 'Time now is %s\n', datestr(now));
    if exist('vSet', 'var'), fprintf(log_file, 'Caller is %s\n', vSet.caller); end
else
    log_file = 1;
end
%----------------------------------------------------------------------------
% Basic mode control parameters
%----------------------------------------------------------------------------
ctrlParam.doPilot           = 0;
ctrlParam.doNFC             = 0;
ctrlParam.doRZ              = 0;
ctrlParam.doNyquist         = 1;
ctrlParam.doRndPMD          = 0;
ctrlParam.doMzmComp         = 1;
ctrlParam.doCoherent        = 1;
ctrlParam.doBPD             = 1;
ctrlParam.doDSP             = 1;
ctrlParam.doPlot            = 0;
ctrlParam.addASE            = 1;
ctrlParam.addCD             = 0;
ctrlParam.addPMD            = 0;
ctrlParam.addPDL            = 0;
ctrlParam.addLaserRIN       = 0;
ctrlParam.addLaserPN        = 0;
ctrlParam.addEndlessSopRot  = 0;
ctrlParam.addThermNoise     = 0;
ctrlParam.addShotNoise      = 0;
ctrlParam.addRIN            = 0;
ctrlParam.addAdcClockJitter = 0;
ctrlParam.addFreqOffset     = 0;
ctrlParam.addQuanzNoise     = 0;
switch MODE
    case 0
        % adopt basic settings
    case 1
        ctrlParam.addCD = 1;
    case 2
        ctrlParam.addLaserPN = 1;
    case 3
        ctrlParam.addPMD = 1;
    case 4
        ctrlParam.addPMD = 1;
        ctrlParam.addPDL = 1;
    otherwise
        keyboard;
end
%----------------------------------------------------------------------------
% constants
%----------------------------------------------------------------------------
LIGHT_SPEED             = 299792458;
BOLTZMAN                = 1.381e-23;
ELECTRON                = 1.602e-19;
TEMPERATURE             = 300;
PD_LOAD_RESISTANCE      = 5000;
CENTER_FREQUENCY        = 193.41e12;
CENTER_WAVELENGTH       = LIGHT_SPEED / CENTER_FREQUENCY;
%----------------------------------------------------------------------------
% the parameters you want to vary
%----------------------------------------------------------------------------
if nargin < 1
    max_run                 = 100;
    hyd90                   = 90;           % degree
    ADC_SAMPLING_RATE       = 2;            % samples per symbol
    DSO_MEMORY_LENGTH       = 100;          % number of frames
    linewidth               = 500e3;        % combined laser linewidth
    osnr                    = 10;           % SNR of one symbol
    baudrate                = 3e9;
    bitpersym               = 2;
    modFormat               = 'QPSK';
    freqOffset              = 1.0e9;
    pulse_shape             = 'RRC';        % RRC Nyquist Bessel Gaussian
    pulse_shape_beta        = 0.35;
    rx_rin                  = -130;
    fiber_spanlen           = 80e3;
    fiber_nspan             = 1;
    detectmod               = 'HOM';            % HOM or HET
    cmrr                    = 30;
else
    max_run                 = vSet.max_run;
    hyd90                   = vSet.hyd90;
    ADC_SAMPLING_RATE       = vSet.ADCfs;
    DSO_MEMORY_LENGTH       = vSet.DSPmemLen; 
    linewidth               = vSet.linewidth;
    osnr                    = vSet.osnr;
    baudrate                = vSet.baudrate;
    bitpersym               = vSet.bitpersym;
    modFormat               = vSet.modFormat;
    freqOffset              = vSet.freqOffset;
    pulse_shape             = vSet.pulse_shape;
    pulse_shape_beta        = vSet.pulse_shape_beta;
    rx_rin                  = vSet.rx_rin;
    fiber_spanlen           = vSet.fiber_spanlen;
    fiber_nspan             = vSet.fiber_nspan;
    detectmod               = vSet.detectmod;
    cmrr                    = vSet.cmrr;
end
% number of qam symbols in the constellation
mn = 2 .^ bitpersym;
% if VERBOSE, fprintf(log_file, 'Modulation Format    %s\n', modFormat); end
% if VERBOSE, fprintf(log_file, 'Pulse-shape          %s\n', pulse_shape); end
% if VERBOSE, fprintf(log_file, 'Detection Mode       %s\n', detectmod); end
%----------------------------------------------------------------------------
% global parameters
%----------------------------------------------------------------------------
fs                  = 16 * baudrate;
baudperframe        = 512;
sps                 = fs / baudrate;
spf                 = baudperframe * sps;
nframe              = 3;
nsample             = nframe * spf;
timeVector          = (0 : nsample-1)' / fs;
freqVector          = get_fft_grid(nsample, fs);
freqVectorFrm       = get_fft_grid(spf, fs);
timeVectorAbs       = timeVector;
%----------------------------------------------------------------------------
vm.StartTime = datestr(now);
%----------------------------------------------------------------------------
% TX
%----------------------------------------------------------------------------
tx.laser.centerFreq     = CENTER_FREQUENCY;
tx.laser.wavelength     = LIGHT_SPEED / CENTER_FREQUENCY;
tx.laser.linewidth      = linewidth;
tx.laser.phaseNoiseVar  = 2 * pi * tx.laser.linewidth / fs;
tx.laser.azimuth        = 0;
tx.laser.ellipticity    = 0;
tx.laser.rin            = -130;
tx.laser.power          = 0.001;
tx.laser.rinvar         = idbw(tx.laser.rin) * (tx.laser.power.^2) * (0.5 * fs);
tx.mod.Vpi              = 3.0;               % [V]
tx.mod.extRatio         = 100;               % [dB]
tx.mod.efficiency       = 0.15;
tx.lpfOrder             = 4;
tx.bandwidth            = 0.75 * baudrate;
tx.pilotX               = [];
tx.pilotY               = [];
%----------------------------------------------------------------------------
% physical fiber parameters
%----------------------------------------------------------------------------
% fiber nonlinearity parameter
fiber.n2 = 2.6e-20;
fiber.coreArea = 80e-12;               % [m^2]
% 
fiber.spanLength        = fiber_spanlen;        % [m]
fiber.spanNum           = 1;
fiber.stepLength        = 1e3;                  % [m]
fiber.corrLength        = 100;                  % [m]
fiber.dispParamD        = 17e-6;                % [s/m]
fiber.dispParamS        = 80;                   % [s/m^2]
fiber.doFullPMD         = 0;
fiber.pmdParam          = 0.5e-12 / sqrt(1000);
fiber.noiseSeed         = 0;
% control the endless polarization rotation speed [rad/s]
fiber.sopRotOmega = 30e3;
fiber.sopRotInit = 0;
% control the pdl effect which may be caused by components other than
% fiber, thus the principle axes of pdl section need NOT to be the same as
% those of fiber [dB]
fiber.pdlAz = pi/2;
fiber.pdlEp = pi/3;
fiber.pdl = idbw(20);
fiber.D = pdl_matrix(fiber.pdl);
% common rotation of psp at central wavelength, which could be an arbitrary
% point on poincare sphere
fiber.sopAz = pi/4;
fiber.sopEp = pi/4;
[fiber.psp, fiber.U] = sop_rotate([1;0], fiber.sopAz, fiber.sopEp);
% average dgd [s] as the length of pmd-vector
fiber.dgd = 1e-12;
% control the phase dispersion effect via pmd-vector, assuming the
% pmd-vector at fiber input is [1;0;0] and output is determined by the
% common rotation at center wavelength
fiber.tau = fiber.dgd * jones2stokes(fiber.psp(1), fiber.psp(2));
fiber.rho = [0;0;0];
% accumulated chromatic dispersion [ns/nm] and chromatic dispersion slop
% [ns/nm/nm]
fiber.DL = fiber.dispParamD * fiber.spanLength * fiber.spanNum;
fiber.SL = fiber.dispParamS * fiber.spanLength * fiber.spanNum;
%----------------------------------------------------------------------------
% channel filtering effects
%----------------------------------------------------------------------------
optFilterOrder = 4;
optFilterBw = 40e9;
%----------------------------------------------------------------------------
% receiver parameters
%----------------------------------------------------------------------------
rx.centerFreq       = CENTER_FREQUENCY;
rx.lpfOrder         = 5;
rx.bandwidth        = 0.75 * baudrate;
rx.laser.wavelength     = LIGHT_SPEED / CENTER_FREQUENCY;
rx.laser.linewidth      = linewidth;
rx.laser.pnvar          = 2 * pi * rx.laser.linewidth / fs;
rx.laser.azimuth        = 45;
rx.laser.ellipticity    = 0;
rx.pbs_power_ratio      = 0.5;
rx.pbs_phase_retard     = 0;
% dBc/Hz, one-sided psd of laser relative intensity noise
rx.laser.rin    = rx_rin;
rx.laser.power  = 0.01;
rx.laser.rinvar = idbw(rx.laser.rin) * (rx.laser.power.^2) * (0.5 * fs);
% common mode rejection ratio (dB) of balanced detector at zero-frequency,
% use this parameter to calculate responsivity of positive and negative
% detector.
rx.cmrr         = cmrr;
rx.resp_pos     = 1.0;
rx.resp_neg     = rx.resp_pos - rx.resp_pos / 10.^(rx.cmrr/20.0);
rx.dark_current = 0.0E-9;
%----------------------------------------------------------------------------
% ADC
%----------------------------------------------------------------------------
% enob defined within signal's bandwidth, used to calculate the power of
% quantization noise and total harmonic distortion.
rx.adc.enob = 10;
rx.adc.sqnr = sqnr(rx.adc.enob);
% fft processing gain of ADC, indicating how many dB the fft noise floor is
% below the quantization noise floor.
rx.adc.nfft = ADC_SAMPLING_RATE * nframe * baudperframe;
rx.adc.fftpgain = 10*log10(rx.adc.nfft/2);
% clipping ratio in dB defined as ratio between clip voltage and rms of adc
% input, close related to the PAR of the input.
rx.adc.clip = 10;
% the amplitude of input sinusoid as percentage of full-scale of adc, which
% is used to *measure* and normalize the enob of an adc, not used in this
% simulation. 95% of full-scale is common.
rx.adc.coverage = 95;
%----------------------------------------------------------------------------
% Calculate the power of electrical noises per quadrature within the
% simulation bandwidth. All noises are modeled as WGN at receiver. Note
% that the noise PSD are defined as one-sided PSD in current.
%----------------------------------------------------------------------------
rx.psdElec = 4 * BOLTZMAN * TEMPERATURE / PD_LOAD_RESISTANCE * (0.5 * fs);
rx.psdShot = 2 * ELECTRON * rx.resp_pos * (rx.laser.power / 2) * (0.5 * fs);
rx.psdRIN  = (rx.resp_pos).^2 * (10.^(-rx.cmrr/20)).^2 * idbw(rx.laser.rin) * (rx.laser.power).^2 * (0.5 * fs) / 4;
%----------------------------------------------------------------------------
% Preparing filter responses
%----------------------------------------------------------------------------
tx.pulseshaper.beta = pulse_shape_beta;
switch pulse_shape
    case {'RC', 'RRC', 'Nyquist'}
        tx.pulseshaper.H = frequency_response(nsample, fs, tx.pulseshaper.beta, baudrate, lower(pulse_shape));
    case {'Bessel', 'Gaussian'}
        tx.pulseshaper.H = frequency_response(nsample, fs, tx.lpfOrder, tx.bandwidth, lower(pulse_shape));
    otherwise
        keyboard;
end
rx.pulseshaper.beta = pulse_shape_beta;
switch pulse_shape
    case {'RC', 'RRC', 'Nyquist'}
        rx.pulseshaper.H = frequency_response(nsample, fs, rx.pulseshaper.beta, baudrate, lower(pulse_shape));
    case {'Bessel', 'Gaussian'}
        rx.pulseshaper.H = frequency_response(nsample, fs, rx.lpfOrder, rx.bandwidth, lower(pulse_shape));
    otherwise
        keyboard;
end
% equivalent noise bandwidth of receiver matched filter
ENBW_RXPS = enbw(rx.pulseshaper.H, fs, 'freq');
optFilter = frequency_response(nsample, fs, optFilterOrder, optFilterBw, 'gaussian');
%----------------------------------------------------------------------------
% Data buffer section. All noise buffers should be filled with proper data
% ar the first run, otherwise the first capture of data for DSP is invalid.
%----------------------------------------------------------------------------
buffer.txBitsX      = randi([0 1], bitpersym, nframe*baudperframe);
buffer.txBitsY      = randi([0 1], bitpersym, nframe*baudperframe);
buffer.txBaudX      = transpose(mqammod(buffer.txBitsX));
buffer.txBaudY      = transpose(mqammod(buffer.txBitsY));
buffer.rxBitsX      = randi([0 1], bitpersym, nframe*baudperframe);
buffer.rxBitsY      = randi([0 1], bitpersym, nframe*baudperframe);
buffer.txPhaseNoise = phase_noise(nsample, tx.laser.phaseNoiseVar, 0);
buffer.rxPhaseNoise = phase_noise(nsample, rx.laser.pnvar, 0);
buffer.txLaserRIN   = zeros(1, nsample);
buffer.rxLaserRIN   = zeros(1, nsample);
buffer.channelNoiseX= zeros(1, nsample);
buffer.channelNoiseY= zeros(1, nsample);
buffer.elecNoiseIx  = zeros(1, nsample);
buffer.elecNoiseQx  = zeros(1, nsample);
buffer.elecNoiseIy  = zeros(1, nsample);
buffer.elecNoiseQy  = zeros(1, nsample);
buffer.shotNoiseIx  = zeros(1, nsample);
buffer.shotNoiseQx  = zeros(1, nsample);
buffer.shotNoiseIy  = zeros(1, nsample);
buffer.shotNoiseQy  = zeros(1, nsample);
%----------------------------------------------------------------------------
vm.tx = tx;
vm.rx = rx;
vm.fiber = fiber;
%----------------------------------------------------------------------------
% Clear memory
memory1 = [];
memory2 = [];
memory3 = [];
memory4 = [];
dspMemCount = 0;
%----------------------------------------------------------------------------
% DSP
%----------------------------------------------------------------------------
% default dsp control
dspParam.showEye            = 0;
dspParam.doFrontEndComp     = 0;
dspParam.doDigitalLPF       = 0;
dspParam.doCDC              = 0;
dspParam.doCDE              = 0;
dspParam.doFramer           = 0;
dspParam.doTraining         = 0;
dspParam.doOneTapPolDemux   = 0;
dspParam.doMIMO             = 0;
dspParam.doTPE              = 0;
dspParam.doCPE              = 0;
dspParam.doLmsAfterCPE      = 0;
dspParam.doFOE              = 0;
dspParam.doFEC              = 0;
dspParam.doDownSampling     = 1;
switch DSPCRT
    case 0
        % adopt basic settings
    case 1
        dspParam.doCDC = 1;
    case 2
        dspParam.doMIMO = 1;
    case 3
        dspParam.doOneTapPolDemux = 1;
    otherwise
end
dspParam.trainingLengthOneTapPolDemux = 100;
dspParam.Rs = baudrate;
dspParam.mn = mn;
dspParam.sps = 2;
dspParam.fs = dspParam.sps * dspParam.Rs;
dspParam.fsADC = 2 * baudrate;
dspParam.DL = fiber.DL;
dspParam.SL = fiber.SL;
dspParam.lambda  = CENTER_WAVELENGTH;
dspParam.lambda0 = CENTER_WAVELENGTH;
dspParam.lpfBW = 0;
dspParam.mimoStep = 1e-3;
dspParam.mimoTapNum = 7;                %7 or 13
dspParam.mimoErrId = 0;
dspParam.mimoIteration = 10;
dspParam.lmsGainAfterCPE = 1e-3;
dspParam.lmsTapsAfterCPE = 125;
dspParam.lmsIterAfterCPE = 4;
dspParam.cpeBlockSize = 16;
dspParam.cpePLLmu = [1e-3, 1e-6];
dspParam.doMLCPE = 2;
dspParam.cpeMLavgLeng = 32;
dspParam.cpeMlIter = 1;
dspParam.vvpeAvgMode = 1;               % 0 for blockwise 1 for sliding window
dspParam.cpeBPSnTestPhase = 10;
dspParam.cpeAlgSelect = 'VVPE';
%------------------------------------------------------------------------
vm.ctrlParam = ctrlParam;
vm.dspParam = dspParam;
%------------------------------------------------------------------------
bitrefx = [];
bitrefy = [];
refBaudX = [];
refBaudY = [];
%------------------------------------------------------------------------
for run = 1 : max_run
%------------------------------------------------------------------------
% Raw bits
%------------------------------------------------------------------------
bitsX = randi([0 1], bitpersym, baudperframe);
bitsY = randi([0 1], bitpersym, baudperframe);
baudX = transpose(mqammod(bitsX));
baudY = transpose(mqammod(bitsY));
% todo add frame headers
% framer_len = 64;
% fifo raw bits
[buffer.txBitsX] = fifo_buffer(buffer.txBitsX, bitsX);
[buffer.txBitsY] = fifo_buffer(buffer.txBitsY, bitsY);
[buffer.txBaudX] = fifo_buffer(buffer.txBaudX, baudX);
[buffer.txBaudY] = fifo_buffer(buffer.txBaudY, baudY);
% in offline mode the center frame is taken as the reference
if DSPMOD == 0
    bitrefx = [bitrefx, buffer.txBitsX(:, (1 : baudperframe) + baudperframe)];
    bitrefy = [bitrefy, buffer.txBitsY(:, (1 : baudperframe) + baudperframe)];
    refBaudX = [refBaudX, buffer.txBaudX(:, (1 : baudperframe) + baudperframe)];
    refBaudY = [refBaudY, buffer.txBaudY(:, (1 : baudperframe) + baudperframe)];
elseif DSPMOD == 1
    bitrefx = buffer.txBitsX(:, (1 : baudperframe) + baudperframe);
    bitrefy = buffer.txBitsY(:, (1 : baudperframe) + baudperframe);
end
tx_baud_px = mqammod(buffer.txBitsX);
tx_baud_py = mqammod(buffer.txBitsY);
%------------------------------------------------------------------------
% TX laser 
%------------------------------------------------------------------------
% buffer laser phase noise
tmpPN = phase_noise(spf, tx.laser.phaseNoiseVar, buffer.txPhaseNoise(end));
buffer.txPhaseNoise = fifo_buffer(buffer.txPhaseNoise, tmpPN);
% buffer laser relative intensity noise
tmpRIN = gaussian_noise(1, spf, tx.laser.rinvar, 'linear', 'real');
buffer.txLaserRIN = fifo_buffer(buffer.txLaserRIN, tmpRIN);
if ctrlParam.addLaserRIN
    if ctrlParam.addLaserPN
        tx.laser.wfm = sqrt(tx.laser.power + buffer.txLaserRIN) .* exp(1i * buffer.txPhaseNoise);
    else
        tx.laser.wfm = sqrt(tx.laser.power + buffer.txLaserRIN);
    end
else
    if ctrlParam.addLaserPN
        tx.laser.wfm = sqrt(tx.laser.power) .* exp(1i * buffer.txPhaseNoise);
    else
        tx.laser.wfm = sqrt(tx.laser.power) * ones(1, nsample);
    end
end
%------------------------------------------------------------------------
% Driver signal for optical modulation with pulse shaping
%------------------------------------------------------------------------
txBaudRealX = real(tx_baud_px) / (sqrt(mn)-1);
txBaudImagX = imag(tx_baud_px) / (sqrt(mn)-1);
txBaudRealY = real(tx_baud_py) / (sqrt(mn)-1);
txBaudImagY = imag(tx_baud_py) / (sqrt(mn)-1);

txDrvIxUps = upsample(txBaudRealX, sps);
txDrvQxUps = upsample(txBaudImagX, sps);
txDrvIyUps = upsample(txBaudRealY, sps);
txDrvQyUps = upsample(txBaudImagY, sps);

txDrvIxWfm = real(ifft(fft(txDrvIxUps) .* tx.pulseshaper.H));
txDrvQxWfm = real(ifft(fft(txDrvQxUps) .* tx.pulseshaper.H));
txDrvIyWfm = real(ifft(fft(txDrvIyUps) .* tx.pulseshaper.H));
txDrvQyWfm = real(ifft(fft(txDrvQyUps) .* tx.pulseshaper.H));

if ctrlParam.doMzmComp
    txDrvIxWfm = asin(txDrvIxWfm) * tx.mod.Vpi /pi;
    txDrvQxWfm = asin(txDrvQxWfm) * tx.mod.Vpi /pi;
    txDrvIyWfm = asin(txDrvIyWfm) * tx.mod.Vpi /pi;
    txDrvQyWfm = asin(txDrvQyWfm) * tx.mod.Vpi /pi;
else
    txDrvIxWfm = (txDrvIxWfm * tx.mod.efficiency) * tx.mod.Vpi /pi;
    txDrvQxWfm = (txDrvQxWfm * tx.mod.efficiency) * tx.mod.Vpi /pi;
    txDrvIyWfm = (txDrvIyWfm * tx.mod.efficiency) * tx.mod.Vpi /pi;
    txDrvQyWfm = (txDrvQyWfm * tx.mod.efficiency) * tx.mod.Vpi /pi;
end
% TODO MZM non-linear pre-comp including the finite extinction ratio
% effect...
%------------------------------------------------------------------------
% MZM, the nonlinear transfer function of MZM will degradate the matched
% filtering
%------------------------------------------------------------------------
V1 = - tx.mod.Vpi / 2;
V2 = - tx.mod.Vpi / 2;
V3 = + tx.mod.Vpi / 2;
tx_os_px = oeModIqNested(tx.laser.wfm, txDrvIxWfm, txDrvQxWfm, tx.mod.extRatio, tx.mod.Vpi, V1, V2, V3);
tx_os_py = oeModIqNested(tx.laser.wfm, txDrvIyWfm, txDrvQyWfm, tx.mod.extRatio, tx.mod.Vpi, V1, V2, V3);
%------------------------------------------------------------------------
% Fiber Channel. If random birefrigence is switched off, use parameterized 
% model. Otherwise, use concantanation psp model.
%------------------------------------------------------------------------
if ~ ctrlParam.doRndPMD
snr = osnr2snr(osnr, baudrate, 'complex');
vm.SNR = snr; vm.OSNR = osnr;
% calc noise power, pulse-shaping is power perserving, oversampling
x_noise_var = dbw(calcrms(tx_os_px).^2) - snr + dbw(sps);
y_noise_var = dbw(calcrms(tx_os_py).^2) - snr + dbw(sps);
% special treatment for the first run, the noise buffer needs to be
% initialized, otherwise the first capture of data would be without
% any channel noise at all
if run == 1
    first_noise_x = gaussian_noise(1, spf, x_noise_var, 'dbw', 'complex');
    first_noise_y = gaussian_noise(1, spf, y_noise_var, 'dbw', 'complex');
    buffer.channelNoiseX = fifo_buffer(buffer.channelNoiseX, first_noise_x);
    buffer.channelNoiseY = fifo_buffer(buffer.channelNoiseY, first_noise_y);
end
% buffer channel noise
channelNoiseX = gaussian_noise(1, spf, x_noise_var, 'dbw', 'complex');
channelNoiseY = gaussian_noise(1, spf, y_noise_var, 'dbw', 'complex');
buffer.channelNoiseX = fifo_buffer(buffer.channelNoiseX, channelNoiseX);
buffer.channelNoiseY = fifo_buffer(buffer.channelNoiseY, channelNoiseY);
if ctrlParam.addASE
    tx_os_px = tx_os_px + buffer.channelNoiseX(:);
    tx_os_py = tx_os_py + buffer.channelNoiseY(:);
end
if ctrlParam.addCD
    % the time independent common phase of fiber transfer matrix
    [fiber.hcd] = chromdisp(nsample, fs, CENTER_WAVELENGTH, CENTER_WAVELENGTH, fiber.DL, fiber.SL);
    tx_os_px = ifft(fft(tx_os_px).* fiber.hcd);
    tx_os_py = ifft(fft(tx_os_py).* fiber.hcd);
end
if ctrlParam.addPMD
    % the time independent common rotation around the central wavelength
    [tx_os_px, tx_os_py] = poltransfer(fiber.U, tx_os_px, tx_os_py);
    % the time independent 1st-order pmd emulator
    [tx_os_px, tx_os_py] = pmd_emulator(tx_os_px, tx_os_py, freqVector, fiber.tau, fiber.rho);
end
if ctrlParam.addPDL
    % time independent pdl section
    [~, tmpU] = sop_rotate([1;0], fiber.pdlAz, fiber.pdlEp);
    [tx_os_px, tx_os_py] = poltransfer(tmpU\fiber.D*tmpU, tx_os_px, tx_os_py);
end
if ctrlParam.addEndlessSopRot
    fiber.sopRotRamp = mod(fiber.sopRotOmega * timeVectorAbs, 2*pi);
    fiber.sopRotAngle = fiber.sopRotInit + fiber.sopRotRamp;
    fiber.sopRotInit = fiber.sopRotAngle(nsample);
    % time dependent endless polarization rotation around the central wavelength
    tmph = tx_os_px .* cos(fiber.sopRotAngle) - tx_os_py .* sin(fiber.sopRotAngle);
    tmpv = tx_os_px .* sin(fiber.sopRotAngle) + tx_os_py .* cos(fiber.sopRotAngle);
    tx_os_px = tmph;
    tx_os_py = tmpv;
    % update absolute time
    timeVectorAbs = ((0 : nsample-1)' + spf) / fs;
end
else
% set initial osnr
% fiber input power control
end
rx_os_px = tx_os_px;
rx_os_py = tx_os_py;
% spectrumAnalyzer([tx_os_px, rx_os_px], [], fs);
%------------------------------------------------------------------------
% RX laser
%------------------------------------------------------------------------
% polarization control
loJonesVector = jones_vector(rx.laser.azimuth, rx.laser.ellipticity);
% buffer laser phase noise
tmpPN = phase_noise(spf, rx.laser.pnvar, buffer.rxPhaseNoise(end));
buffer.rxPhaseNoise = fifo_buffer(buffer.rxPhaseNoise, tmpPN);
% buffer laser relative intensity noise
tmpRIN = gaussian_noise(1, spf, rx.laser.rinvar, 'linear', 'real');
buffer.rxLaserRIN = fifo_buffer(buffer.rxLaserRIN, tmpRIN);
if ctrlParam.addLaserRIN
    if ctrlParam.addLaserPN
        rx.laser.wfm = sqrt(rx.laser.power + buffer.rxLaserRIN) .* exp(1i * buffer.rxPhaseNoise);
    else
        rx.laser.wfm = sqrt(rx.laser.power + buffer.rxLaserRIN);
    end
else
    if ctrlParam.addLaserPN
        rx.laser.wfm = sqrt(rx.laser.power) .* exp(1i * buffer.rxPhaseNoise);
    else
        rx.laser.wfm = sqrt(rx.laser.power) * ones(1, length(buffer.rxLaserRIN));
    end
end
%------------------------------------------------------------------------
% Detection front-end
%------------------------------------------------------------------------
% control the polarization
rx.laser.wfm = loJonesVector * sqrt(abs(rx.laser.wfm).^2) .* [sign(rx.laser.wfm); sign(rx.laser.wfm)];

% PBS / PBC
loLaserPx = sqrt(rx.pbs_power_ratio) * exp(-1i * rx.pbs_phase_retard) * rx.laser.wfm(1,:).';
loLaserPy = sqrt(1 - rx.pbs_power_ratio) * rx.laser.wfm(2,:).';

% Hybrid
hybrid90 = deg2rad(hyd90);

switch detectmod
    case 'HOM'
        if ctrlParam.addFreqOffset
            xRealP = rx_os_px + exp(1i * 2*pi * freqOffset * timeVector) .*  loLaserPx;
            xRealN = rx_os_px + exp(1i * 2*pi * freqOffset * timeVector) .* -loLaserPx;
            xImagP = rx_os_px + exp(1i * 2*pi * freqOffset * timeVector) .*  exp(1i * hybrid90) .* loLaserPx;
            xImagN = rx_os_px + exp(1i * 2*pi * freqOffset * timeVector) .* -exp(1i * hybrid90) .* loLaserPx;
            yRealP = rx_os_py + exp(1i * 2*pi * freqOffset * timeVector) .*  loLaserPy;
            yRealN = rx_os_py + exp(1i * 2*pi * freqOffset * timeVector) .* -loLaserPy;
            yImagP = rx_os_py + exp(1i * 2*pi * freqOffset * timeVector) .*  exp(1i * hybrid90) .* loLaserPy;
            yImagN = rx_os_py + exp(1i * 2*pi * freqOffset * timeVector) .* -exp(1i * hybrid90) .* loLaserPy;
        else
            xRealP = rx_os_px + loLaserPx;
            xRealN = rx_os_px - loLaserPx;
            xImagP = rx_os_px + exp(1i * hybrid90) .* loLaserPx;
            xImagN = rx_os_px - exp(1i * hybrid90) .* loLaserPx;
            yRealP = rx_os_py + loLaserPy;
            yRealN = rx_os_py - loLaserPy;
            yImagP = rx_os_py + exp(1i * hybrid90) .* loLaserPy;
            yImagN = rx_os_py - exp(1i * hybrid90) .* loLaserPy;
        end
    case 'HET'
        if ctrlParam.addFreqOffset
            xHetP = rx_os_px + exp(1i * 2*pi * freqOffset * timeVector) .*  loLaserPx;
            xHetN = rx_os_px + exp(1i * 2*pi * freqOffset * timeVector) .* -loLaserPx;
            yHetP = rx_os_py + exp(1i * 2*pi * freqOffset * timeVector) .*  loLaserPy;
            yHetN = rx_os_py + exp(1i * 2*pi * freqOffset * timeVector) .* -loLaserPy;
        else
            xHetP = rx_os_px + loLaserPx;
            xHetN = rx_os_px - loLaserPx;
            yHetP = rx_os_py + loLaserPy;
            yHetN = rx_os_py - loLaserPy;
        end
    otherwise
        warning('unsupported detection mode'); keyboard;
end

%------------------------------------------------------------------------
% Photo detector, need model dark current
%------------------------------------------------------------------------
% dark current
IpdDark = rx.dark_current;
switch detectmod
    case 'HOM'
        V1 = rx.resp_pos .* abs(xRealP).^2;
        V2 = rx.resp_neg .* abs(xRealN).^2;
        V3 = rx.resp_pos .* abs(xImagP).^2;
        V4 = rx.resp_neg .* abs(xImagN).^2;
        V5 = rx.resp_pos .* abs(yRealP).^2;
        V6 = rx.resp_neg .* abs(yRealN).^2;
        V7 = rx.resp_pos .* abs(yImagP).^2;
        V8 = rx.resp_neg .* abs(yImagN).^2;
        if ctrlParam.addThermNoise
            IpdThermal1 = gaussian_noise(size(V1,1), size(V1,2), rx.psdElec, 'linear', 'real');
            IpdThermal2 = gaussian_noise(size(V3,1), size(V3,2), rx.psdElec, 'linear', 'real');
            IpdThermal3 = gaussian_noise(size(V5,1), size(V5,2), rx.psdElec, 'linear', 'real');
            IpdThermal4 = gaussian_noise(size(V7,1), size(V7,2), rx.psdElec, 'linear', 'real');
        else
            IpdThermal1 = 0;
            IpdThermal2 = 0;
            IpdThermal3 = 0;
            IpdThermal4 = 0;
        end
        if ctrlParam.addShotNoise
            IpdShot1 = gaussian_noise(size(V1,1), size(V1,2), rx.psdShot, 'linear', 'real');
            IpdShot2 = gaussian_noise(size(V1,1), size(V1,2), rx.psdShot, 'linear', 'real');
            IpdShot3 = gaussian_noise(size(V1,1), size(V1,2), rx.psdShot, 'linear', 'real');
            IpdShot4 = gaussian_noise(size(V1,1), size(V1,2), rx.psdShot, 'linear', 'real');
        else
            IpdShot1 = 0;
            IpdShot2 = 0;
            IpdShot3 = 0;
            IpdShot4 = 0;
        end
        if ctrlParam.addRIN
            IpdRIN1 = gaussian_noise(size(V1,1), size(V1,2), rx.psdRIN, 'linear', 'real');
            IpdRIN2 = gaussian_noise(size(V1,1), size(V1,2), rx.psdRIN, 'linear', 'real');
            IpdRIN3 = gaussian_noise(size(V1,1), size(V1,2), rx.psdRIN, 'linear', 'real');
            IpdRIN4 = gaussian_noise(size(V1,1), size(V1,2), rx.psdRIN, 'linear', 'real');
        else
            IpdRIN1 = 0;
            IpdRIN2 = 0;
            IpdRIN3 = 0;
            IpdRIN4 = 0;
        end
        if ctrlParam.doBPD 
            pd_xi = V1 - V2 + IpdThermal1 + IpdShot1 + IpdDark + IpdRIN1;
            pd_xq = V3 - V4 + IpdThermal2 + IpdShot2 + IpdDark + IpdRIN2;
            pd_yi = V5 - V6 + IpdThermal3 + IpdShot3 + IpdDark + IpdRIN3;
            pd_yq = V7 - V8 + IpdThermal4 + IpdShot4 + IpdDark + IpdRIN4;
        else
            pd_xi = V1 + IpdThermal1 + IpdShot1 + IpdDark;
            pd_xq = V3 + IpdThermal2 + IpdShot2 + IpdDark;
            pd_yi = V5 + IpdThermal3 + IpdShot3 + IpdDark;
            pd_yq = V7 + IpdThermal4 + IpdShot4 + IpdDark;
        end
        % perform matched filtering
        pd_xi = real(ifft(fft(pd_xi) .* rx.pulseshaper.H));
        pd_xq = real(ifft(fft(pd_xq) .* rx.pulseshaper.H));
        pd_yi = real(ifft(fft(pd_yi) .* rx.pulseshaper.H));
        pd_yq = real(ifft(fft(pd_yq) .* rx.pulseshaper.H));
        
    case 'HET'
        % square law detection
        V1 = rx.resp_pos .* abs(xHetP).^2;
        V2 = rx.resp_pos .* abs(xHetN).^2;
        V3 = rx.resp_pos .* abs(yHetP).^2;
        V4 = rx.resp_pos .* abs(yHetN).^2;
        if ctrlParam.addThermNoise
            IpdThermal1 = gaussian_noise(size(V1,1), size(V1,2), rx.psdElec, 'linear', 'real');
            IpdThermal2 = gaussian_noise(size(V1,1), size(V1,2), rx.psdElec, 'linear', 'real');
        else
            IpdThermal1 = 0;
            IpdThermal2 = 0;
        end
        if ctrlParam.addShotNoise
            IpdShot1 = gaussian_noise(size(V1,1), size(V1,2), rx.psdShot, 'linear', 'real');
            IpdShot2 = gaussian_noise(size(V1,1), size(V1,2), rx.psdShot, 'linear', 'real');
        else
            IpdShot1 = 0;
            IpdShot2 = 0;
        end
        if ctrlParam.addRIN
            IpdRIN1 = gaussian_noise(size(V1,1), size(V1,2), rx.psdRIN, 'linear', 'real');
            IpdRIN2 = gaussian_noise(size(V1,1), size(V1,2), rx.psdRIN, 'linear', 'real');
        else
            IpdRIN1 = 0;
            IpdRIN2 = 0;
        end
        if ctrlParam.doBPD % balanced detection
            pd_xi = V1 - V2 + IpdDark + IpdThermal1 + IpdShot1 + IpdRIN1;
            pd_yi = V3 - V4 + IpdDark + IpdThermal2 + IpdShot2 + IpdRIN2;
        else
            pd_xi = V1 + IpdDark + IpdThermal1 + IpdShot1;
            pd_yi = V3 + IpdDark + IpdThermal2 + IpdShot2;
        end
        
        % low-pass filtering
        pd_xi = real(ifft(fft(pd_xi) .* rx.pulseshaper.freqRespBessel));
        pd_yi = real(ifft(fft(pd_yi) .* rx.pulseshaper.freqRespBessel));
end
%------------------------------------------------------------------------
% ADC, need a realistic sampling rate, add timing jitter here
%------------------------------------------------------------------------
ad_head = 1;
switch detectmod
    case 'HOM'
        adc1 = pd_xi(ad_head : sps/ADC_SAMPLING_RATE : end);
        adc2 = pd_xq(ad_head : sps/ADC_SAMPLING_RATE : end);
        adc3 = pd_yi(ad_head : sps/ADC_SAMPLING_RATE : end);
        adc4 = pd_yq(ad_head : sps/ADC_SAMPLING_RATE : end);
        if ctrlParam.addQuanzNoise
            pqn1 = calcrms(adc1).^2 / idbw(rx.adc.sqnr);
            pqn2 = calcrms(adc1).^2 / idbw(rx.adc.sqnr);
            pqn3 = calcrms(adc1).^2 / idbw(rx.adc.sqnr);
            pqn4 = calcrms(adc1).^2 / idbw(rx.adc.sqnr);
            qn1  = gaussian_noise(size(adc1,1), size(adc1,2), pqn1, 'linear', 'real');
            qn2  = gaussian_noise(size(adc2,1), size(adc2,2), pqn2, 'linear', 'real');
            qn3  = gaussian_noise(size(adc3,1), size(adc3,2), pqn3, 'linear', 'real');
            qn4  = gaussian_noise(size(adc4,1), size(adc4,2), pqn4, 'linear', 'real');
            adc1 = adc1 + qn1;
            adc2 = adc2 + qn2;
            adc3 = adc3 + qn3;
            adc4 = adc4 + qn4;
        end
    case 'HET'
        adc1 = pd_xi(ad_head : sps/ADC_SAMPLING_RATE : end);
        adc2 = pd_yi(ad_head : sps/ADC_SAMPLING_RATE : end);
        if ctrlParam.addQuanzNoise
            pqn1 = calcrms(adc1).^2 / idbw(rx.adc.sqnr);
            pqn2 = calcrms(adc1).^2 / idbw(rx.adc.sqnr);
            qn1  = gaussian_noise(size(adc1,1), size(adc1,2), pqn1, 'linear', 'real');
            qn2  = gaussian_noise(size(adc2,1), size(adc2,2), pqn2, 'linear', 'real');
            adc1 = adc1 + qn1;
            adc2 = adc2 + qn2;
        end
end
%------------------------------------------------------------------------
% Interfacing with DSP
%------------------------------------------------------------------------
if DSPMOD == 0
    adc_out_len = length(adc1);
    % push only the center frame to the memory
    memory1 = [memory1; adc1(adc_out_len / nframe + 1 : end - adc_out_len / nframe, 1)];
    memory2 = [memory2; adc2(adc_out_len / nframe + 1 : end - adc_out_len / nframe, 1)];
    memory3 = [memory3; adc3(adc_out_len / nframe + 1 : end - adc_out_len / nframe, 1)];
    memory4 = [memory4; adc4(adc_out_len / nframe + 1 : end - adc_out_len / nframe, 1)];
    dspMemCount = dspMemCount + 1;
    if dspMemCount == DSO_MEMORY_LENGTH
        fprintf(strcat(datestr(now), sprintf('  [OFFLINE DSP] In total %d frames are captured', dspMemCount)));
        fprintf('\n');
        break;
    end
elseif DSPMOD == 1
    if VERBOSE && (run == 1), fprintf('REAL-TIME DSP...\n'); end
    dsp_inx = adc1 + 1i * adc2;
    dsp_iny = adc3 + 1i * adc4;
    % DC blocker, essential to handling the constant constellation
    % shift caused by cmrr.
    dsp_inx = dsp_inx - mean(dsp_inx);
    dsp_iny = dsp_iny - mean(dsp_iny);
    % TODO orthonormalization
    if dspParam.doCDC
        dns = numel(dsp_inx);
        dfs = ADC_SAMPLING_RATE * baudrate;
        [fiber.hcd] = chromdisp(dns, dfs, CENTER_WAVELENGTH, CENTER_WAVELENGTH, fiber.DL, fiber.SL);
        dsp_cd_1 = ifft(fft(dsp_inx) .* conj(fiber.hcd));
        dsp_cd_2 = ifft(fft(dsp_iny) .* conj(fiber.hcd));
        dsp_outx = dsp_cd_1(dns / nframe + 1 : end - dns / nframe);
        dsp_outy = dsp_cd_2(dns / nframe + 1 : end - dns / nframe);
    else
        dns = numel(dsp_inx);
        dsp_outx = dsp_inx(dns / nframe + 1 : end - dns / nframe);
        dsp_outy = dsp_iny(dns / nframe + 1 : end - dns / nframe);
    end
    dsp_outx = dsp_outx(1 : 2 : end);
    dsp_outy = dsp_outy(1 : 2 : end);
    bitx = qamdemod(dsp_outx, mn);
    bity = qamdemod(dsp_outy, mn);
    nerlog(run, :) = [nnz(bitx - bitrefx), nnz(bity - bitrefy)];
end
end % this is the end of main loop
%----------------------------------------------------------------------------
% Post-processing
%----------------------------------------------------------------------------
if DSPMOD == 0
    dspParam.refBaudX = refBaudX(:);
    dspParam.refBaudY = refBaudY(:);
    [dsp_outx, dsp_outy, vm.dsp] = dsp_main(memory1, memory2, memory3, memory4, dspParam);
    figure(3); plot(dsp_outx, '.'); hold on; plot(dsp_outy, '.'); grid on; hold off;
    bitx = qamdemod(dsp_outx, mn);
    bity = qamdemod(dsp_outy, mn);
    [berx, itvx] = berconfint(nnz(bitx - bitrefx), numel(bitx), 0.95);
    [bery, itvy] = berconfint(nnz(bity - bitrefy), numel(bity), 0.95);
else
    ner = sum(nerlog);
    [berx, itvx] = berconfint(ner(1), numel(bitrefx)*max_run, 0.95);
    [bery, itvy] = berconfint(ner(2), numel(bitrefy)*max_run, 0.95);
end
vm.BER   = 0.5 * [berx + bery, itvx + itvy];
vm.BER_T = berawgn(vm.SNR - dbw(bitpersym), 'qam', mn, 'nodiff');
if VERBOSE && (vm.BER(1) >= vm.BER_T)
    fprintf(strcat(datestr(now), sprintf('  BER = [%.4e, %.4e, %.4e]\n', berx, bery, vm.BER_T)));
    fprintf('\n');
end
if VERBOSE && (vm.BER(1) < vm.BER_T)
    fprintf(strcat(datestr(now), sprintf('  BER*** = [%.4e, %.4e, %.4e]\n', berx, bery, vm.BER_T)));
    fprintf('\n');
end
if VERBOSE, fprintf('------------------------------\n'); end
%----------------------------------------------------------------------------
vm.EndTime = datestr(now);

% [] Arburg
% [] Fixed point -> quantizer
% [] Bandpass sampling -> test
% [] Constellation ML decision
% [] Noise whitening filter
% [x] Channel coefficients estimate - LMS
% [] MLSE
% [] Kalman filter
% [] Water filling
% [x] Effective noise bandwidth
% [x] ENOB
% [x] Quantization noise
% [] Timing jitter
% [] Skew
% [] Theoretical BER of m-QAM
% [] DFT -> pre-sum DFT, spectrum estimation
% [] BER confidence interval 

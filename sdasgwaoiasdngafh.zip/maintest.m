%===========================================================================
% OFFLINE dsp with default dsp control
% vm = go(vset, 0, 1, 0, 0, 0) for back-to-back test 
% vm = go(vset, 0, 1, 1, 0, 0) for chromatic dispersion test
% vm = go(vset, 0, 1, 1, 0, 1) for chromatic dispersion compensation test
% vm = go(vset, 0, 1, 3, 0, 0) for sop rotation test
% vm = go(vset, 0, 1, 3, 0, 3) for one-tap sop compensation test
% vm = go(vset, 0, 1, 4, 0, 3) for one-tap sop compensation with pdl test
% ONLINE dsp with default dsp control
% vm = go(vset, 0, 1, 0, 1, 0) for back-to-back test 
% vm = go(vset, 0, 1, 1, 1, 0) for chromatic dispersion test
% vm = go(vset, 0, 1, 1, 1, 1) for chromatic dispersion compensation test
%===========================================================================
clear
osnr = 4 : .5 : 14;
% osnr = 14;
for ii = 1 : length(osnr)
    vset.max_run            = 100;
    vset.hyd90              = 90;       % degree
    vset.ADCfs              = 2;        % samples per symbol
    vset.DSPmemLen          = 100;      % number of frames
    vset.linewidth          = 500e3;
    vset.osnr               = osnr(ii);
    vset.baudrate           = 30e9;
    vset.bitpersym          = 2;
    vset.modFormat          = 'QPSK';
    vset.freqOffset         = 1.0e9;
    vset.pulse_shape        = 'RRC';
    vset.pulse_shape_beta   = 0.65;
    vset.rx_rin             = -130;
    vset.fiber_spanlen      = 150e3;
    vset.fiber_nspan        = 1;
    vset.detectmod          = 'HOM';
    vset.cmrr               = 30;
    %--------------------------
%     vm = go(vset, 0, 1, 0, 0, 0);
%     vm = go(vset, 0, 1, 1, 0, 0);
%     vm = go(vset, 0, 1, 1, 0, 1);
%     vm = go(vset, 0, 1, 3, 0, 0);
%     vm = go(vset, 0, 1, 3, 0, 3);
    vm = go(vset, 0, 1, 4, 0, 3);
%     vm = go(vset, 0, 1, 0, 1, 0);
%     vm = go(vset, 0, 1, 1, 1, 0);
%     vm = go(vset, 0, 1, 1, 1, 1);
    %--------------------------
    ber(ii)      = vm.BER(1);
    snr(ii)      = vm.SNR;
    ber_t(ii)    = vm.BER_T;
    ber_ci(ii,:) = vm.BER(2:3);
end
plot_ber_snr(snr', ber', ber_t', ber_ci);

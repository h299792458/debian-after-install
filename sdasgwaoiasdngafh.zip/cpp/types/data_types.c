#include <stdio.h>
#include <limits.h>

#ifdef LINUX
#include <stdlib.h>
#endif

using namespace std;

int main() {
    printf("size of short is %lu bytes\n", sizeof(short));
    printf("size of long is %lu bytes\n", sizeof(long));
    printf("size of long long is %lu bytes\n", sizeof(long long));
    printf("size of char is %lu bytes\n", sizeof(char));
    printf("size of float is %lu bytes\n", sizeof(float));
    printf("size of double is %lu bytes\n", sizeof(double));
    printf("size of int is %lu bytes\n", sizeof(int));
    printf("size of unsigned int is %lu bytes\n", sizeof(unsigned int));
    printf("size of short int is %lu bytes\n", sizeof(short int));
    printf("size of long int is %lu bytes\n", sizeof(long int));
    printf("size of long long int is %lu bytes\n", sizeof(long long int));
    return 0;
}

#include "fftw3.h"
#include <pthread.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

#define NUM_POINTS  65536
#define NUM_THREADS 4

fftw_complex signal[NUM_POINTS];
fftw_complex result[NUM_POINTS];
fftw_plan plan = fftw_plan_dft_1d(NUM_POINTS, signal, result, 
                                FFTW_FORWARD, FFTW_ESTIMATE);
pthread_mutex_t mutex;

void acquire_signal(fftw_complex *signal)
{
    for (int i = 0; i < NUM_POINTS; ++i)
    {
        double theta = (double)i / (double)NUM_POINTS * M_PI;
        signal[i][0] = 1.0 * cos(10.0 * theta) + 0.5 * cos(25.0 * theta);
        signal[i][1] = 1.0 * sin(10.0 * theta) + 0.5 * sin(25.0 * theta);
    }
}

void do_something_with(fftw_complex *result)
{
    for (int i = 0; i < NUM_POINTS; ++i)
    {
        double mag = sqrt(result[i][0] * result[i][0] +
                          result[i][1] * result[i][1]);
    }
}

void *worker_thread(void *arg)
{
    printf("In worker_thread() with ID %ld: working hard\n", (long)arg);
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < 2000; i++) fftw_execute(plan);
    pthread_mutex_unlock(&mutex);
    /* Cleanup: the pthread_exit() routine does not close files; any files opened 
       inside the thread will remain open after the thread is terminated. */
    pthread_exit((void*)"worker_thread terminated with success");
}

int main()
{
    printf("In main(): creating thread\n");
    int num_thread = NUM_THREADS;
    long thread_id[num_thread];
    /* declare a void * pointer to accept any type of return status from a 
       thread */
    void *exit_stat;
    acquire_signal(signal);
    pthread_t my_thread[num_thread];
    for (int i = 0; i < num_thread; i++) {
        thread_id[i] = (i + 1) * 100;
        pthread_create(&my_thread[i], NULL, &worker_thread, (void *)thread_id[i]);
    }
    /* join my_thread one by one to make sure all tasks have been completed. 
       pthread_join() will suspend the calling thread and will wait for the 
       other thread to terminate. note that &(*) = **, the cast of void ** 
       is redundant. */
    for (int i = 0; i < num_thread; i++) {
        pthread_join(my_thread[i], (void **)&exit_stat);
        printf("%s\n", (char *)exit_stat);
    }
    do_something_with(result);
    fftw_destroy_plan(plan);
    /* the main() calls pthread_exit() to make sure that all threads it has 
       created will continue to run. Otherwise, they will be automatically 
       terminated when main() finishes. */
    pthread_exit(NULL);
    return 0;
}

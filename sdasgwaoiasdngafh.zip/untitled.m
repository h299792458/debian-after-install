clear
J = sop_rotate([1;0],pi/4,0);
az = linspace(0,pi/20,20);
ep = linspace(0,pi/40,20);
ss = 1;
for aa = 1:length(az)
    for ee = 1:length(ep)
        tmp = sop_rotate(J,az(aa),ep(ee));
        S(:,ss) = jones2stokes(tmp(1), tmp(2));
        ss = ss + 1;
    end
end
poincare_sphere(); plot3(S(1,:), S(2,:), S(3,:), 'o', 'MarkerFaceColor', 'auto');
function hcd = design_hcd(K, N)
% Design the time-domain impulse response of the chromatic dispersion
% compensation filter

% half of tap number
Nf = (N - 1) / 2;

%----------------------------------------------------------------------------
% Filter #1 designed by the time sampling method (TSM), i.e., taking the
% inverse Fourier transform of the all-pass chromatic dispersion frequency
% response with angular frequency from -inf to inf. This gives an impulse
% response with constant magnitude and a corresponding DTFT with
% non-constant magnitude
%----------------------------------------------------------------------------
for n = -Nf : Nf
    hcd_A1(n + Nf + 1) = sqrt(1i / (4*K*pi)) * exp(-1i * n^2 / (4*K));
end

%----------------------------------------------------------------------------
% Filter #2 designed by the frequency sampling method (FSM), i.e., taking
% the inverse DFT of discrete chromatic dispersion frequency response with
% digital frequencies from -pi to pi. This will produce an impulse response
% with non-constant magnitude and a corresponding DTFT with N points
% specified. Note that the operation of fftshift introduces a linear phase
% to the designed frequency response. Note that this is equivalent to
% solving the problem of D*h[n] = H[k], where D is an NxN DFT matrix, and
% h and H has N points. The solution is given by hcd_A2 = inverse(D)*H,
% where D = dftmtx(N) is the DFT matrix.
%----------------------------------------------------------------------------
W = [0:Nf, -Nf:-1] * 2 * pi / N;
H = exp(1i * K * W.^2);
hcd_A2 = fftshift(ifft(H));

%----------------------------------------------------------------------------
% filter #3 designed by FSM with oversampling. Note that this is equivalent
% to solving the lease squares problem of D*h[n] = H[k], where D is an MxN
% DFT matrix, h has N points, and H has M points. The solution is given by
% h = inverse(D'*D)*D'*H. When M is large and the desired frequency
% response is sampled from -pi to pi, the least squares criteria approaches
% the mean squared error criteria over the full band, and according the
% convergence of Fourier series, the solution of minimizing the MSE is the
% ideal Fourier series truncated with an N-point rectangular windown. On
% the other hand, oversampling the ideal frequency response heavily reduces
% time aliasing and therefore the inverse DFT produces an impulse response
% close enough to the ideal impulse response.
%----------------------------------------------------------------------------
% M = 8192;
% isodd = mod(M, 2);
% iseve = 1 - isodd;
% W = get_fft_grid(M, 2*pi);
% H = exp(1i * K * W.^2);
% hcd_A3 = fftshift(ifft(H));
% hcd_A3 = hcd_A3(M/2-Nf+iseve : M/2+Nf+iseve);
% % D = dftmtx(M);
% % D = [D(:,1:Nf+isodd), D(:,end-Nf+isodd:end)];
% % hcd_A3_1 = (D' * D) \ D' * H;
% % figure; stem(hcd_A3); hold on; stem(fftshift(hcd_A3_1));
% hcd_A3 = transpose(hcd_A3);

M = 8192;
L = 2000;
isodd = mod(M, 2);
W = get_fft_grid(M, 2*pi);
H = exp(1i * K * W.^2);
H = [H(1:M/2-L); H(end-M/2+L+1:end)];
D = dftmtx(M);
D = [D(1:M/2-L,:); D(end-M/2+L+1:end,:)];
D = [D(:,1:Nf+isodd), D(:,end-Nf+isodd:end)];
hcd_A3 = (D' * D + 1e-5 * eye(N)) \ D' * H;
hcd_A3 = fftshift(transpose(hcd_A3));

%----------------------------------------------------------------------------
% filter #4 and #5 designed by windowing filter #1 by raised-cosine with
% various roll-off
%----------------------------------------------------------------------------
arc = 0.15;
for n = -Nf : Nf
    if abs(n) < (1-arc) / 2 * Nf
        hrc(n + Nf + 1) = 1;
    elseif abs(n) > (1+arc) / 2 * Nf
        hrc(n + Nf + 1) = 0;
    else
        hrc(n + Nf + 1) = 0.5 * (1 + cos(pi / (arc * Nf) * (abs(n) - (1-arc) / 2 *Nf)));
    end
end
hcd_A4 = hcd_A1 .* hrc;

arc = 0.85;
for n = -Nf : Nf
    if abs(n) < (1-arc) / 2 * Nf
        hrc(n + Nf + 1) = 1;
    elseif abs(n) > (1+arc) / 2 * Nf
        hrc(n + Nf + 1) = 0;
    else
        hrc(n + Nf + 1) = 0.5 * (1 + cos(pi / (arc * Nf) * (abs(n) - (1-arc) / 2 *Nf)));
    end
end
hcd_A5 = hcd_A1 .* hrc;

%----------------------------------------------------------------------------
% filter #6 designed by applying FSM to the Wiener deconvolution filter in
% frequency domain. It has the same group delay as the direct FSM but with
% magnitude optimized for noise suppression
%----------------------------------------------------------------------------
M = 8192;
% isodd = mod(M, 2);
% iseve = 1 - isodd;
% G = frequency_response(M, 2, 0.15, 1, 'rc');
% W = get_fft_grid(M, 2*pi);
% H = exp(1i * K * W.^2) .* G.^2 ./ (G.^2 + 0.01);
% hcd_A6 = fftshift(ifft(H));
% hcd_A6 = hcd_A6(M/2-Nf+iseve : M/2+Nf+iseve);
% D = dftmtx(M);
% D = [D(:,1:Nf+isodd), D(:,end-Nf+isodd:end)];
% hcd_A6_1 = (D' * D) \ D' * H;
% figure; stem(hcd_A6); hold on; stem(fftshift(hcd_A6_1));
% hcd_A6 = transpose(hcd_A6);

L = 2000;
isodd = mod(M, 2);
G = frequency_response(M, 2, 0.15, 1, 'rc');
W = get_fft_grid(M, 2*pi);
H = exp(1i * K * W.^2) .* G.^2 ./ (G.^2 + 0.01);
H = [H(1:M/2-L); H(end-M/2+L+1:end)];
D = dftmtx(M);
D = [D(1:M/2-L,:); D(end-M/2+L+1:end,:)];
D = [D(:,1:Nf+isodd), D(:,end-Nf+isodd:end)];
hcd_A6 = (D' * D + 1e-5 * eye(N)) \ D' * H;
hcd_A6 = fftshift(transpose(hcd_A6));

hcd = [hcd_A1; hcd_A2; hcd_A3; hcd_A4; hcd_A5; hcd_A6];
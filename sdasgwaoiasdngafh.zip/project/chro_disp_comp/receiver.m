function ber = receiver(sps, G, hcd, x, rawbits)
hcd_A1 = hcd(1, :);
hcd_A2 = hcd(2, :);
hcd_A3 = hcd(3, :);
hcd_A4 = hcd(4, :);
hcd_A5 = hcd(5, :);
hcd_A6 = hcd(6, :);

x_inph = real(ifft(fft(real(x)).* G));
x_quad = real(ifft(fft(imag(x)).* G));

% use 2 sps
L = 2;
x = x_inph(1:sps/L:end) + 1i * x_quad(1:sps/L:end);

x_fltd(:, 1) = conv(x, hcd_A1, 'same');
x_fltd(:, 2) = conv(x, hcd_A2, 'same');
x_fltd(:, 3) = conv(x, hcd_A3, 'same');
x_fltd(:, 4) = conv(x, hcd_A4, 'same');
x_fltd(:, 5) = conv(x, hcd_A5, 'same');
x_fltd(:, 6) = conv(x, hcd_A6, 'same');

% final estimate
x_hat(:, 1) = x_fltd(1:2:end, 1);
x_hat(:, 2) = x_fltd(1:2:end, 2);
x_hat(:, 3) = x_fltd(1:2:end, 3);
x_hat(:, 4) = x_fltd(1:2:end, 4);
x_hat(:, 5) = x_fltd(1:2:end, 5);
x_hat(:, 6) = x_fltd(1:2:end, 6);

ALPHABET_SIZE = 16;

debit_A1 = qamdemod(normalization(x_hat(:,1), ALPHABET_SIZE), ALPHABET_SIZE);
debit_A2 = qamdemod(normalization(x_hat(:,2), ALPHABET_SIZE), ALPHABET_SIZE);
debit_A3 = qamdemod(normalization(x_hat(:,3), ALPHABET_SIZE), ALPHABET_SIZE);
debit_A4 = qamdemod(normalization(x_hat(:,4), ALPHABET_SIZE), ALPHABET_SIZE);
debit_A5 = qamdemod(normalization(x_hat(:,5), ALPHABET_SIZE), ALPHABET_SIZE);
debit_A6 = qamdemod(normalization(x_hat(:,6), ALPHABET_SIZE), ALPHABET_SIZE);

ber_A1 = nnz(debit_A1 - rawbits) / numel(rawbits);
ber_A2 = nnz(debit_A2 - rawbits) / numel(rawbits);
ber_A3 = nnz(debit_A3 - rawbits) / numel(rawbits);
ber_A4 = nnz(debit_A4 - rawbits) / numel(rawbits);
ber_A5 = nnz(debit_A5 - rawbits) / numel(rawbits);
ber_A6 = nnz(debit_A6 - rawbits) / numel(rawbits);

ber = [ber_A1, ber_A2, ber_A3, ber_A4, ber_A5, ber_A6];
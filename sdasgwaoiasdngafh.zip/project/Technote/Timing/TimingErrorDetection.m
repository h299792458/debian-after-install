%===========================================================================
% Test Part I - principle of spectral autocorrelation for timing error
% detection
% 
% This type of timing error detection uses a very simple Fourier transform
% property, i.e., time shift corresponds a phase ramp in spectrum.
% Therefore, the imaginary part of auto-correlation of spectrum with a
% fixed lag would be a TED with sinusoid characteristics. The smaller the
% lag, the longer range of detectable timing error.
%
% If the lag of auto-correlation is equal to the symbol rate, the range of
% detectable timing error is within one symbol duration.
%===========================================================================
clear
close all
% number of DFT
nfft = 4096;
% freq of signal
f1 = 1000;
f2 = 2000;
% sampling speed
fs = 8000;
%
nsample = 3850;

% signal with 2 distinct frequencies
ntau = -4 : 0.1 : 4;
for ii = 1 : length(ntau)
    signal_1 = exp(1i * 2 * pi * f1 * ((0 : nsample - 1) + ntau(ii)) ./ fs);
    signal_2 = exp(1i * 2 * pi * f2 * ((0 : nsample - 1) + ntau(ii)) ./ fs);
    signal = signal_1 + signal_2;
    
    % a single real frequence should also work...
%     signal = real(signal_1); ndx2 = 3585;
    
    % get the periodogram, zero-padding the signal to nfft, power of 2
    SS = fft(signal, nfft) / nfft;
    
    ndx1 = 513;
    ndx2 = 1025;
    
    range = -15 : 15;
    timing_error(ii) = -imag(sum(SS(range + ndx1) .* conj(SS(range + ndx2))));
end
figure; stem(ntau / (fs / f1), timing_error, 'filled'); grid on
xlabel('Timing error');
ylabel('TED output');



%===========================================================================
% Test Part II - mqam timing error detection
%===========================================================================
clear
% mqam signal generation
mqam_generator;

for ii = 1 : sps
    ss = mqam_signal(ii : sps/2 : end); % 2 sps downsampling

%     timing_error(ii) = timing_error_detector(ss(:), 'AVN');
%     timing_error(ii) = timing_error_detector(ss(:), 'SLN');
%     timing_error(ii) = timing_error_detector(ss(:), 'FLN');
%     timing_error(ii) = timing_error_detector(ss(:), 'LOGN');
%     timing_error(ii) = timing_error_detector(ss(:), 'LEE');
    timing_error(ii) = timing_error_detector(ss(:), 'GARDNER');
%     timing_error(ii) = timing_error_detector(ss(:), 'GODARD');
%     timing_error(ii) = timing_error_detector(ss(:), 'DTP');
%     timing_error(ii) = timing_error_detector(ss(:), 'SLN_ITP');
end
figure; stem((1:sps) / sps, timing_error, 'filled'); grid on
xlabel('Timing error');
ylabel('TED output');

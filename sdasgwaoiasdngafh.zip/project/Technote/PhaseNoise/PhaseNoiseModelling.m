%===========================================================================
% This script demos the phase noise modelling technique. The phase noise is
% modeled as discrete Wiener process, which is not a WSS process but is
% still gaussian with increasing variance. Therefore, when simulating the
% *physical* phase noise, the critical point would be to ensure that we are
% end up with the same phase vaiance at the simulation finish time t,
% independent of the simulation bandwidth. 
% 
% The physical phase variance at time t can be extrapolated from measured
% phase vaiance of a known data sequence with repetition rate of xx Hz.
% 
% Suppose the known data sequence has period of T. We have measured the
% variance of phase difference between consecutive symbols, which we
% consider as WGN, as Vs. Therefore, the phase vaiance at time t would be
% t*Vs/T. By simulating the same system with an oversampling of M, the
% variance of phase difference between consecutive symbols must be Vs/M.
% 
% Test: PhaseNoiseModelling(2, 1)
%       PhaseNoiseModelling(2, 2)
%       PhaseNoiseModelling(2, 4)
%       PhaseNoiseModelling(2, 8)
%       PhaseNoiseModelling(2, 16)
% 
% Definition of "phase different": phase difference is the phase derivative
% in discrete cases, hence it describes the discrete frequency noise, which
% in practical is a colored gaussian noise (Hz^2/Hz). In most simulations,
% however, it is treated simply as WGN.
% 
% Once the parameter of the physical phase noise is determined, one should
% observe decrease of variation of the phase difference as the baudrate
% increases. Although high baudrate signal observes more phase noise when
% the receiver performs matched filtering, the effect can be somehow
% neglected due to the extremely lowpassed nature of phase noise,
% especially when compared to the bandwidth of practical communication
% signal.
%===========================================================================
function [] = PhaseNoiseModelling(k, baudrate)
if nargin < 1, k = 2; end
if nargin < 2, baudrate = 1; end
RandStream.setGlobalStream(RandStream('mt19937ar','Seed',1234));
fs = 64;
% baudrate = 1;
sps = fs / baudrate;
nbaud = 2^16;
nsample = sps * nbaud;

txbits = randi([0 1], k, nbaud);
txbaud = mqammod(txbits);

alpha = 0.05;
H = frequency_response(nsample, fs, alpha, baudrate, 'rrc');
sym_upsampled = upsample(txbaud(:), sps);
sym_upsampled_i = real(ifft(fft(real(sym_upsampled)) .* H));
sym_upsampled_q = real(ifft(fft(imag(sym_upsampled)) .* H));
tx_wmf = sym_upsampled_i + 1i * sym_upsampled_q;

% add *physical* phase noise without bandwidth limitation (well)
pvar = 1e-3;
pn = phase_noise(nsample, pvar, 0);
% data model
rx_wmf = tx_wmf .* exp(1i * pn(:));

% matched filtering, with the phase noise lowpass filtered as well
signal_i = real(ifft(fft(real(rx_wmf)) .* H));
signal_q = real(ifft(fft(imag(rx_wmf)) .* H));
rxbaud = signal_i(1:sps:end) + 1i * signal_q(1:sps:end);

% note that the phase noise actually destroys the matched filtering
% scatterplot(rxbaud);

% estimate the phase difference, which should be a WGN with power
% proportional to the sampling interval T
espn = unwrap(angle(rxbaud.*conj(txbaud)));
wvar = var(diff(espn));
unct = 2.6 * (2*wvar^2/(nbaud-1)); % 99% CI

fprintf('phase noise variation within %d bauds is %.4e with uncertainty %.4e \n', nbaud, wvar, unct);

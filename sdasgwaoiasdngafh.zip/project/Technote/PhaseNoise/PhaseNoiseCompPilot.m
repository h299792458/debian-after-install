%===========================================================================
% Noise analysis on phase recovery based on pilot-tone. The phase noise is
% first estimated from a lowpass filtered pilot-tone, then the desired
% signal is compensated with estimated phase.
% 
% The data model in the filtered region can be expressed as p+w with p
% being the pilot and w the WGN. The compensation process is therefore
% (p+w) * conj(p+w) / |p+w|, which is |p+w|^2 / |p+w| = |p+w|, i.e.,
% everything goes to the real axis. It is easy to verify that the total
% power of p+w doesn't change but more power is shifted to the
% zero-frequency and the PSD level of WGN after phase recovery actually
% drops.
% 
% For p and w separately, the compensation result in (|p|^2+pw^*) and
% (|w|^2+wp^*), respectively. Note that they are still noise like.
% 
% If thers is another signal aside the pilot-tone waiting for the phase
% noise compensation, it's better not to be too close to the pilot-tone
% otherwise part of the singal will be REDUCED TO ONE DIMENSION as well.
% Although one can observe a noise power reduction in the signal......
%===========================================================================
clear
close all

fc = 1e6;
fs = 20e6;
nsample = 10^5;
t = (0 : (1/fs) : (nsample-1)/fs)';
pn = phase_noise(nsample, 1e-3, 0);
an = gaussian_noise(nsample, 1, .3, 'linear', 'complex');
x = exp(1i * pn(:)) + an;
H = frequency_response(nsample, fs, 0.01, 6e6, 'rc');
xf = ifft(fft(x) .* H);
xc = x .* conj(xf) ./ abs(xf);
nc = an .* conj(xf) ./ abs(xf);

% observe there is a peak in nc, and xc has lower WGN PSD
spectrumAnalyzer([x, xc], [], fs);
spectrumAnalyzer([an(:), nc(:)], [], fs);

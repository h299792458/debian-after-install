%===========================================================================

%===========================================================================
function fft_effect(sigma2)
if nargin < 1, sigma2 = 1e-4; end
fs = 200e6;
nsample = 4096;
freq = get_fft_grid(nsample, fs);
% random walk phase noise, the spectrum of random walk has Lorentzian shape
pn = phase_noise(nsample, sigma2, 0);
w = gaussian_noise(size(pn,1), size(pn,2), .1, 'linear', 'complex');
x = exp(1i * pn) + w;
%----------------------------------------------------------------------------
% shift the psd in freq domain
%----------------------------------------------------------------------------
df = 49.9999e6;
ef = exp(1i*2*pi*df.*(0:nsample-1)./fs);
wd = ones(1, numel(x));
psd_s = abs(fft((x - w).*ef.*wd)) .^ 2 / (nsample * nsample);

figure(1); hold on
plot(fftshift(freq), dbw(fftshift(psd_s))); grid on;

wd = transpose(chebwin(numel(x)));
psd_s = abs(fft((x - w).*ef.*wd)) .^ 2 / (nsample * nsample);
plot(fftshift(freq), dbw(fftshift(psd_s))); grid on;

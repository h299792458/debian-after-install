%===========================================================================
% mqam signal generation template
%===========================================================================
sps = 64;
nbaud = 4096;
nsamp = sps * nbaud;

% NUMBER OF BIT PER SYMBOL
k = 2;
refbit = randi([0 1], k, nbaud);

% mapping bit to symbol
bauds = mqammod(refbit);

% pulse-shaping, get a freq domain raised cosine filter response
H = frequency_response(nsamp, sps, 0.35, 1, 'rc');
bauds_upsampled = upsample(bauds(:), sps);

% filtering signal in frequency domain
temp_i = real(ifft(fft(real(bauds_upsampled)) .* H));
temp_q = real(ifft(fft(imag(bauds_upsampled)) .* H));
mqam_signal = temp_i + 1i * temp_q;

snr = 20;
pw = calcrms(mqam_signal).^2 / idbw(snr);
ww = gaussian_noise(size(mqam_signal,1), size(mqam_signal,2), pw, 'linear', 'complex');
mqam_signal = mqam_signal + ww;

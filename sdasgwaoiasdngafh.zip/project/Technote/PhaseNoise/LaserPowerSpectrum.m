%===========================================================================
% Discrete phase noise is modeled as random walk
% 
% Try sigma2 = 2. The spectral line shape looks gaussian.
% Try sigma2 = 2e-3. The spectral line shape looks lorentzian.
% Try even smaller sigma2 = 2e-6. Bad model.
%
% A noncausal Wiener filter is also demonstrated to estimate the
% target, i.e., pilot-tone with phase noise exp(i*theta), from its noisy
% measurement.
%
% Refs: [1] MIT course 6.011 chapter 11 Wiener filter
% 
%       [2] Magarini, Maurizio, et al. "Empirical modeling and simulation
%           of phase noise in long-haul coherent optical transmission
%           systems." Optics Express 19.23 (2011): 22455-22461.
%
%       [3] Di Domenico, Gianni, Stéphane Schilt, and Pierre Thomann.
%           "Simple approach to the relation between laser frequency noise
%           and laser line shape." Applied optics 49.25 (2010): 4801-4807.
% 
% Tests: LaserPowerSpectrum(.1)
%        LaserPowerSpectrum(.01)
%        LaserPowerSpectrum(.001)
%        LaserPowerSpectrum(.0001)
%        LaserPowerSpectrum(.00001)
%        LaserPowerSpectrum(.000001)
%===========================================================================
function LaserPowerSpectrum(sigma2)
if nargin < 1, sigma2 = 2e-3; end
fs = 2e6;
nsample = 10^5;
freq = get_fft_grid(nsample, fs);
for ii = 1 : 50
    % random walk phase noise, the spectrum of random walk has Lorentzian shape
    pn = phase_noise(nsample, sigma2, 0);
    w = gaussian_noise(size(pn,1), size(pn,2), .1, 'linear', 'complex');
    x = exp(1i * pn) + w;
    
    % the signal has another Lorentzian spectrum line shape
    psd(ii, :) = abs(fft(x)) .^ 2 / (nsample * nsample);
    psd_s(ii, :) = abs(fft(x - w)) .^ 2 / (nsample * nsample);
    psd_w(ii, :) = abs(fft(w)) .^ 2 / (nsample * nsample);
end

% signalSpectrum = mean(abs(psd));
wgnSpectrum = mean(abs(psd_w));
laserPowerSpectrum = mean(abs(psd_s));

figure;
plot(fftshift(freq), dbw(fftshift(wgnSpectrum))); hold on;
% plot the measured PSD
% plot(fftshift(freq), dbw(fftshift(signalSpectrum)));
% plot the target PSD
plot(fftshift(freq), dbw(fftshift(laserPowerSpectrum))); grid on;
%----------------------------------------------------------------------------
% theoretical model of target PSD, todo, need the coeff at the center
%----------------------------------------------------------------------------
L = 4 * sigma2 ./ fs ./ (sigma2^2 + 16 * pi * pi * freq.^2 ./ (fs)^2);
% normalize
L = L / max(L) * max(laserPowerSpectrum) / 2;
plot(fftshift(freq), dbw(fftshift(L)), 'LineWidth', 2);
%----------------------------------------------------------------------------
% spectral estimation based on AR model
%----------------------------------------------------------------------------
pxx = pburg(x-w, 1, length(x));
pxx = pxx / max(pxx) * max(L);
plot(fftshift(freq), dbw(fftshift(pxx)), 'LineWidth', 2);
%----------------------------------------------------------------------------
% Wiener filter
%----------------------------------------------------------------------------
H = L ./ (L + mean(wgnSpectrum));
H = H(:) / max(H) * max(L);
plot(fftshift(freq), dbw(fftshift(H)), 'LineWidth', 2);
legend('WGN', 'Target PSD', 'Lorentzian', 'AR(1)', 'Wiener filter');

% y = ifft(fft(x) .* H);
% figure;
% plot(unwrap(angle(x - w))); hold on; 
% plot(unwrap(angle(y))); grid on;

%===========================================================================
% simulate parametrization of jones matrix, i.e., unitary jones matrix can
% be parameterized by linear combination of 4 pauli matrices with real
% coefficients, whereas generic jones matrix can be parameterized by linear
% combination of 4 pauli matrices with complex coefficients. 
%===========================================================================
clear

% Pauli vector
p0 = [1 0; 0 1];
p1 = [0 1; 1 0];
p2 = [0 -1i; 1i, 0];
p3 = [1 0; 0 -1];

% coefficients
h = rand(1,3);
h0 = rand(1,1);
% h = rand(1,3) + 1i * rand(1,3);
% h0 = rand(1,1) + 1i * rand(1,1);

% matrix exponential
U = expm(1i * (h0 * p0 + h(1) * p1 + h(2) * p2 + h(3) * p3));
d = det(U)
a = U * U'

% unitary matrix can be further factorized into a common phase and a
% speical unitary matrix
SU = U.* exp(-1i * h0);
d = det(SU)
a = SU * SU'

% alternative form of SU
% t = norm(h);
% SU = p0 * cos(t) + 1i * (h(1) * p1 + h(2) * p2 + h(3) * p3) /t * sin(t);

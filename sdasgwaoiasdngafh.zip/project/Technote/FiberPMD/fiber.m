%===========================================================================
% simulate a fiber with random first-order linear birefringence at single
% frequency
%===========================================================================
clear

% center frequency
f = 299792458 / 1550e-9;
omega = 2 * pi * f;
% fiber length
L = 100e3;
% number of sections should be large enough for covergence to true pdf
N = 37;
% DGD parameter
DGD_Param = 1e-12 / sqrt(1000);
% mean DGD
DGD_Mean = DGD_Param * sqrt(L);
% DGD in each section
DGD_Section = DGD_Mean * sqrt(3 * pi /8 / N);

% [Main Loop with Many Trials on Different Fiber Realizations]
for tt = 1:5000

% [Jones Matrix]
% random orientation of each fiber section
theta = rand(1, N) * pi;
% test input signal - 45 degree linearly polarized
Ein = [1; 1];
J   = [1 0; 0 1];
% model each section as a rotated linear birefringence component
for ss = 1:N
    D{ss} = [exp(1i * omega * DGD_Section/2), 0; 0, exp(-1i * omega * DGD_Section/2)];
    M{ss} = rotation_matrix(-theta(ss)) * D{ss} * rotation_matrix(theta(ss));
    J     = M{ss} * J;
end
% get the output
Eout = J * Ein;
% converted to stokes space, take only the first sample...
s(:,tt) = jones2stokes(Eout(1), Eout(2));

% [Evolution of PMD-vector]
tau = [0;0;0];
for ss = 1:N
    % input pmd-vector of each section aligning with the birefringence
    % axis, i.e. eigenvector of M{ss}
    tau_tmp = [cos(theta(ss)); sin(theta(ss))];
    % concatenation rule
    for ii = 1:(N-ss+1)
        tau_tmp = M{ii} * tau_tmp;
    end
    tau_tmp = DGD_Section * jones2stokes(tau_tmp(1), tau_tmp(2));
    tau = tau + tau_tmp;
end
% the dgd is the length of pmd-vector
DGD(tt) = norm(tau);
end

poincare_sphere(); plot3(s(1,:), s(2,:), s(3,:), 'o', 'MarkerFaceColor', 'auto');

% maxiwellian pdf in theory
t = 0 : .1e-12 : 30e-12;
pMxw = (3 * t.^2 / (DGD_Section.^3 * N)) .* sqrt(6 / pi / N) .* exp(-3 * t.^2 / (2 * N * DGD_Section.^2));
p = sum(pMxw);
pMxw = pMxw ./ p;

figure();
h = histogram(DGD,'Normalization','pdf'); 
values = h.BinEdges(1:end-1) + h.BinWidth/2.0;
counts = h.Values / p;
plot(values, counts, 'o'); hold on; 
plot(t, pMxw, 'LineWidth', 2); grid on; 
legend('Simulation', 'Theory');

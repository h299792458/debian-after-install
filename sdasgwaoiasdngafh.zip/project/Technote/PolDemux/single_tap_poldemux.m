%===========================================================================
% PMD, PDL and Phase Noise Transparent Single-Tap Polarization
% Demultiplexing for Clock Recovery
%===========================================================================
function [ner] = single_tap_poldemux(snr, k)
if nargin < 1, snr = idbw(15); end
if nargin < 2, k = 2; end

sps = 16;
nsymbol = 2^16;
nsample = sps * nsymbol;
alpha = 0.15;
H = frequency_response(nsample, sps, alpha, 1, 'rrc');
bits_h = randi([0 1], k, nsymbol);
baud_h = upsample(mqammod(bits_h), sps);
ah = real(ifft(fft(real(baud_h)) .* H));
bh = real(ifft(fft(imag(baud_h)) .* H));
bits_v = randi([0 1], k, nsymbol);
baud_v = upsample(mqammod(bits_v), sps);
av = real(ifft(fft(real(baud_v)) .* H));
bv = real(ifft(fft(imag(baud_v)) .* H));
S = [ah + 1i*bh, av + 1i*bv].';

% varying channel matrix at carrier frequency
tv = 1:nsample;
fr = 1/nsample;
theta = 2*pi*fr*tv;
ep = pi/3;
C  = zeros(2, 2, nsample);
C(1, 1, :) =  cos(theta);
C(2, 1, :) = -sin(theta) .* exp(1i * ep);
C(1, 2, :) =  sin(theta) .* exp(-1i * ep);
C(2, 2, :) =  cos(theta);
PDL = 1;   % dB
rho = (idbw(PDL) - 1) / (idbw(PDL) + 1);
D    = zeros(2, 2);
D(1) = sqrt(1 - rho);
D(4) = sqrt(1 + rho);
az = pi / 4;
ep = pi / 6;
R = zeros(2, 2);
R(1) =  cos(az);
R(2) = -sin(az) * exp(1i * ep);
R(3) =  sin(az) * exp(-1i * ep);
R(4) =  cos(az);
D = R \ D * R;
T  = zeros(2, 2, nsample);
for ii = 1:nsample
    T(:,:,ii) = D * C(:,:,ii);
end

% phase noise
PN = phase_noise(nsample, 1e-4, 0);
E  = exp(1i * ones(2, 1) * PN);

% two channels have independent noise and snr
ps = mean(calcrms((T(:,:,1) * S).').^2);
V  = gaussian_noise(2, nsample, ps/snr, 'linear', 'complex');

% channel
X = zeros(size(S));
for ii = 1:nsample
    X(:,ii) = (T(:,:,ii) * S(:,ii)) .* E(:,ii) + V(:,ii);
end

% receiver
X = X.';
ah = real(ifft(fft(real(X(:,1))) .* H));
bh = real(ifft(fft(imag(X(:,1))) .* H));
Yh = ah(1:sps:end) + 1i * bh(1:sps:end);
av = real(ifft(fft(real(X(:,2))) .* H));
bv = real(ifft(fft(imag(X(:,2))) .* H));
Yv = av(1:sps:end) + 1i * bv(1:sps:end);
Y = [Yh, Yv].';
% bits = qamdemod(baud, 2^k);
N = numel(Y) / 2;
S = S(:, 1:sps:end);

% single-tap lms equalizer
F = zeros(N,2);
G = zeros(N,2);
mu = 0.02;
Z = zeros(size(Y));
for k = 2:N
    F(k,:) = F(k-1,:) - mu * (F(k-1,:)*Y(:,k) - S(1,k)) * Y(:,k)';
    G(k,:) = G(k-1,:) - mu * (G(k-1,:)*Y(:,k) - S(2,k)) * Y(:,k)';
    M = [F(k,:); G(k,:)];
    Z(:,k) = M * Y(:,k);
end

scatterplot(Z(1,2000:end)); grid on;
scatterplot(Y(1,2000:end)); grid on;

% single-tap estimator + wiener
F = zeros(N,2);
G = zeros(N,2);
mu = 0.02;
Z = zeros(size(Y));
for k = 2:N
    F(k,:) = F(k-1,:) - mu * (F(k-1,:)*S(:,k) - Y(1,k)) * S(:,k)';
    G(k,:) = G(k-1,:) - mu * (G(k-1,:)*S(:,k) - Y(2,k)) * S(:,k)';
    M = [F(k,:); G(k,:)];
    Z(:,k) = (M' * M + eye(2)/snr) \ M' * Y(:,k);
end

figure; subplot(211); plot(1:N, real(F.'), 1:N, real(G.')); grid on;
subplot(212); plot(1:nsample, real(squeeze(T(1,:,:))), 1:nsample, real(squeeze(T(2,:,:)))); grid on;
figure; subplot(211); plot(1:N, imag(F.'), 1:N, imag(G.')); grid on;
subplot(212); plot(1:nsample, imag(squeeze(T(1,:,:))), 1:nsample, imag(squeeze(T(2,:,:)))); grid on;

scatterplot(Z(1,2000:end)); grid on;
scatterplot(Y(1,2000:end)); grid on;
%===========================================================================
% Phase and Polarization Tracking 
% 
% The transfer function of lossless fiber channel can be described by
% either Jones matrix or Stokes matrix. The Jones matrix is in general a
% 2x2 complex-valued unitary matrix that has 4 degrees of freedom (DOF), 3
% of which describes the change of SOP and one describes the change of
% common phase. The Stokes (Muller) matrix is in general a 3x3 real-valued
% orthogonal matrix that has only 3 DOF, the change of common phase is lost
% however.
%
% Parametering the Jones matrix by using matrix exponetials, both common
% phase and SOP can be jointly tracked with adaptive filter. On the other
% hand, SOP can be tracked in Stokes space which is immune to phase noise,
% and the phase can be tracked in a separated stage.
%
% Alternatively, the Jones matrix can be writtens as a 4D real-valued
% matrix which has 16 elements and 6 DOF. However, it can be shown that
% only 4 of them are physical and the phase and polarization joint tracking
% can be performed as well as in the Jones space.
%
% [1] Bilal, Syed M., and Gabriella Bosco. "Pilot tones based
%     polarization rotation, frequency offset and phase estimation for
%     polarization multiplexed Offset-QAM Multi-Subcarrier coherent optical
%     systems." Transparent Optical Networks (ICTON), 2016 18th International
%     Conference on. IEEE, 2016. 
% [2] Czegledi, Cristian B., et al. "Modulation format independent joint
%     polarization and phase tracking for coherent receivers." Journal of
%     Lightwave Technology 34.14 (2016): 3354-3364.
% [3] Muga, Nelson J., and Armando Nolasco Pinto. "Adaptive 3-D Stokes
%     space-based polarization demultiplexing algorithm." Journal of Lightwave
%     Technology 32.19 (2014): 3290-3298.
%===========================================================================
% scheme 2 assuming contant sop with phase noise (the change of sop is
% much slower than that of phase noise), the tx sends random pilot symbols
% only on both polarizations, and the rx estimates the channel matrix using
% the detected random pilot symbols (corrupted with phase noise) first, and
% phase noise compensation is done after the channel matrix rotation.
%===========================================================================
function [ner] = LS_ChMtxEst_Wiener_PolDemux(snr)

if nargin < 1, snr = 1.5; end

% the fiber transfer matrix at central frequency
az = (rand() - 0.5) * 2 * pi;
ep = (rand() - 0.5) * 2 * pi;
C  = zeros(2, 2);
C(1) =  cos(az);
C(2) = -sin(az) * exp(1i * ep);
C(3) = -conj(C(2));
C(4) =  conj(C(1));

% C = [-0.8495 + 0.0000i, -0.0537 + 0.5249i;
%       0.0537 + 0.5249i, -0.8495 + 0.0000i];

% PDL section 
PDL = 2; %dB
rou = (idbw(PDL) - 1) / (idbw(PDL) + 1);
D    = zeros(2, 2);
D(1) = sqrt(1 - rou);
D(4) = sqrt(1 + rou);
az = pi / 4;
ep = pi / 6;
R = zeros(2, 2);
R(1) =  cos(az);
R(2) = -sin(az) * exp(1i * ep);
R(3) = -conj(R(2));
R(4) =  conj(R(1));

T = R \ D * R * C;
% T = eye(2); % for benchmark

n = 10^6;

% pilot with random modulated symbols 
% >>>>> A(1, :) = 0 will make (A' * A) singular 
AI = (randi([0, 1], 2, n) - 0.5) * 2;
AQ = (randi([0, 1], 2, n) - 0.5) * 2;
% % qpsk version 
% A  = AI + 1i * AQ;
% bpsk version 
A  = AI;
% database = load('as.mat');
% A(:, 1:length(database.As)) = database.As;
% signal channel
SI = (randi([0, 1], 2, n) - 0.5) * 2;
SQ = (randi([0, 1], 2, n) - 0.5) * 2;
S  = SI + 1i * SQ;

PN = phase_noise(n, 1e-3, 0);
E  = exp(1i * ones(2, 1) * PN);

% two channels have independent noise and snr
pa = mean(calcrms((T * A).').^2);
ps = mean(calcrms((T * S).').^2);
W  = gaussian_noise(2, n, pa/100, 'linear', 'complex');
V  = gaussian_noise(2, n, ps/snr, 'linear', 'complex');

% channel 
B = T * A .* E + W;
Q = T * S .* E + V;
% B = T * A + W; % for benchmark
% Q = T * S + V; % for benchmark

% rather short training sequence is good enough to avoid the singularity of
% (Bs * Bs') in case of high snr. 
len = 50;
Bs  = B(:, 1:len);
As  = A(:, 1:len);
Qs  = Q(:, 1:len);
Ss  = S(:, 1:len);

% #1 least squares estimation of sop, treating the phase noise as another
% additive noise (or simply as a constant rotation if the traning is short)
% which will cause a phase rotation of estimated channel matrix. 
% T_e = B * A' * inv(A * A');
T_e = Bs * As' / (As * As');
% T_e = Qs * Ss' / (Ss * Ss'); % for benchmark

% sop correction using lmmse filter, when T_e is close to be unitary, the
% snr value does not really matter. A_e is estimation of A*E
A_e = (T_e' * T_e + eye(2)/100) \ T_e' * B;
S_e = (T_e' * T_e + eye(2)/snr) \ T_e' * Q;

% #2 zero-forcing equivalent to #1 without the eye term
% A_e = (As * As') / (Bs * As') * B;

% #2 lmmse filter (training/pilot mode) note that snr estiamte is implicit
% in this case. **perform worse than #1 due to a bad snr estimate when the
% channel matrix is NOT unitary**
A_ee = As * Bs' / (Bs * Bs') * B;
S_ee = As * Bs' / (Bs * Bs') * Q;
% A_e = T_e \ B; % for benchmark
% S_e = T_e \ Q; % for benchmark

% #3 phase noise on both polarizations are aligned which allows joint phase
% estimation. 
pn = unwrap(angle(sum(A_e .* conj(A))));
S_f = S_e .* exp(-1i * ones(2,1) * pn);
S_g = S_ee .* exp(-1i * ones(2,1) * pn);
S_f = S_f ./ mean(calcrms(S_f));
S_g = S_g ./ mean(calcrms(S_g));
% S_f = S_e ./ mean(calcrms(S_e)); % for benchmark
% S_g = S_ee ./ mean(calcrms(S_ee)); % for benchmark

ner = [nnz(qamdemod(S_f(1,:).', 4) - qamdemod(S(1,:).', 4));
       nnz(qamdemod(S_g(1,:).', 4) - qamdemod(S(1,:).', 4))];


% figure(1); 
% plot(PN); hold on; 
% plot(pn); grid on; hold off;
% 
% figure(2)
% subplot(211); stem(real(T(1:4)), 'filled'); hold on;
% stem(real(T_e(1:4)), 'filled'); grid on; hold off;
% ylim([-1, 1]); ylabel('Re(T)');
% subplot(212); stem(imag(T(1:4)), 'filled'); hold on;
% stem(imag(T_e(1:4)), 'filled'); grid on; hold off;
% ylim([-1, 1]); ylabel('Re(T)');
% 
% figure(3); 
% plot(S_f(1, :), '.'); hold on;
% plot(S_f(2, :), '.'); hold off; grid on;
% xlim([-2, 2]); 
% ylim([-2, 2]); 
% title(sprintf('BER = %.2f', ber));
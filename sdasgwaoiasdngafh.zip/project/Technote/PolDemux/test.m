clear 

snr = 0.02 : 0.01 : 0.1;
itr = 100;
for ss = 1:length(snr)
    for ii = 1:itr
        tmp = scheme_b(snr(ss));
        nera(ii,ss) = tmp(1);
        nerb(ii,ss) = tmp(2);
    end
end

[bera, ecia] = berconfint(sum(nera), itr*2*10^6, 0.99);
[berb, ecib] = berconfint(sum(nerb), itr*2*10^6, 0.99);

cia = ecia - bera(:) * ones(1,2);
cib = ecib - berb(:) * ones(1,2);
figure(); 
errorbar(10*log10(snr), bera, cia(:,1), cia(:,2)); hold on; 
errorbar(10*log10(snr), berb, cib(:,1), cib(:,2)); hold on; 
plot(10*log10(snr), snr2ber(snr,2,'linear')); grid on 

%===========================================================================
% Phase and Polarization Tracking 
% 
% Estimate channel matrix by using LMS algorithm and use the estimated
% results to update the Wiener filter for polarization demultiplexing
%===========================================================================
function [ner] = LMS_ChMtxEst_Wiener_PolDemux(snr)
if nargin < 1, snr = idbw(25); end
N = 2000;  % number of samples
tv = 1:N;
fr = 1/2000;
% varying channel matrix at carrier frequency
theta = 2*pi*fr*tv;
ep = pi/3;
C  = zeros(2, 2, N);
C(1, 1, :) =  cos(theta);
C(2, 1, :) = -sin(theta) .* exp(1i * ep);
C(1, 2, :) =  sin(theta) .* exp(-1i * ep);
C(2, 2, :) =  cos(theta);
PDL = 3;   % dB
rho = (idbw(PDL) - 1) / (idbw(PDL) + 1);
D    = zeros(2, 2);
D(1) = sqrt(1 - rho);
D(4) = sqrt(1 + rho);
az = pi / 4;
ep = pi / 6;
R = zeros(2, 2);
R(1) =  cos(az);
R(2) = -sin(az) * exp(1i * ep);
R(3) =  sin(az) * exp(-1i * ep);
R(4) =  cos(az);
D = R \ D * R;
T  = zeros(2, 2, N);
for ii = 1:N
    T(:,:,ii) = D * C(:,:,ii);
end
% dul pol signal
SI = (randi([0, 1], 2, N) - 0.5) * 2;
SQ = (randi([0, 1], 2, N) - 0.5) * 2;
S  = SI + 1i * SQ;
% phase noise
PN = phase_noise(N, 1e-50, 0);
E  = exp(1i * ones(2, 1) * PN);
% two channels have independent noise and snr
ps = mean(calcrms((T(:,:,1) * S).').^2);
V  = gaussian_noise(2, N, ps/snr, 'linear', 'complex');
% channel
X = zeros(size(S));
for ii = 1:N
    X(:,ii) = (T(:,:,ii) * S(:,ii)) .* E(:,ii) + V(:,ii);
end
F = zeros(N,2);
G = zeros(N,2);
mu = 0.02;
for k = 2:N
    F(k,:) = F(k-1,:) - mu * (F(k-1,:)*S(:,k) - X(1,k)) * S(:,k)';
    G(k,:) = G(k-1,:) - mu * (G(k-1,:)*S(:,k) - X(2,k)) * S(:,k)';
end
figure; subplot(211); plot(1:N, real(F.'), 1:N, real(G.')); grid on;
subplot(212); plot(1:N, real(squeeze(T(1,:,:))), 1:N, real(squeeze(T(2,:,:)))); grid on;
figure; subplot(211); plot(1:N, imag(F.'), 1:N, imag(G.')); grid on;
subplot(212); plot(1:N, imag(squeeze(T(1,:,:))), 1:N, imag(squeeze(T(2,:,:)))); grid on;
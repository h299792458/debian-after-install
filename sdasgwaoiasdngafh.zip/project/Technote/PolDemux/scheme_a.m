%===========================================================================
% Phase and Polarization Tracking 
% 
% The transfer function of lossless fiber channel can be described by
% either Jones matrix or Stokes matrix. The Jones matrix is in general a
% 2x2 complex-valued unitary matrix that has 4 degrees of freedom (DOF), 3
% of which describes the change of SOP and one describes the change of
% common phase. The Stokes (Muller) matrix is in general a 3x3 real-valued
% orthogonal matrix that has only 3 DOF, the change of common phase is lost
% however.
%
% Parametering the Jones matrix by using matrix exponetials, both common
% phase and SOP can be jointly tracked with adaptive filter. On the other
% hand, SOP can be tracked in Stokes space which is immune to phase noise,
% and the phase can be tracked in a separated stage.
%
% Alternatively, the Jones matrix can be writtens as a 4D real-valued
% matrix which has 16 elements and 6 DOF. However, it can be shown that
% only 4 of them are physical and the phase and polarization joint tracking
% can be performed as well as in the Jones space.
%
% [1] Bilal, Syed M., and Gabriella Bosco. "Pilot tones based
%     polarization rotation, frequency offset and phase estimation for
%     polarization multiplexed Offset-QAM Multi-Subcarrier coherent optical
%     systems." Transparent Optical Networks (ICTON), 2016 18th International
%     Conference on. IEEE, 2016. 
% [2] Czegledi, Cristian B., et al. "Modulation format independent joint
%     polarization and phase tracking for coherent receivers." Journal of
%     Lightwave Technology 34.14 (2016): 3354-3364.
% [3] Muga, Nelson J., and Armando Nolasco Pinto. "Adaptive 3-D Stokes
%     space-based polarization demultiplexing algorithm." Journal of Lightwave
%     Technology 32.19 (2014): 3290-3298.
%===========================================================================
% scheme 1 assuming contant sop with phase noise (the change of sop is
% much slower than that of phase noise), the tx sends random pilot symbols
% with periodic constant pilot symbols inserted on both polarizations, and
% the rx uses the stronger detected constant pilot to estimate the pahse
% noise first, then the channel matrix is estimated by the random pilot
% symbols and compensated.
clear

az = (rand() - 0.5) * 2 * pi;
ep = (rand() - 0.5) * 2 * pi;
C  = zeros(2, 2);
C(1) =  cos(az);
C(2) = -sin(az) * exp(1i * ep);
C(3) = -conj(C(2));
C(4) =  conj(C(1));

% PDL section
PDL = 1.5; %dB
rou = (idbw(PDL) - 1) / (idbw(PDL) + 1);
D    = zeros(2, 2);
D(1) = sqrt(1 - rou);
D(4) = sqrt(1 + rou);
az = pi / 4;
ep = pi / 16;
R = zeros(2, 2);
R(1) =  cos(az);
R(2) = -sin(az) * exp(1i * ep);
R(3) = -conj(R(2));
R(4) =  conj(R(1));

T = R \ D * R * C;

n = 5000;

% input interleaved with constant pilot
% note that A(1, :) = 0 will make (A' * A) singular
AI = (randi([0, 1], 2, n) - 0.5) * 2;
AQ = (randi([0, 1], 2, n) - 0.5) * 2;
% % qpsk version
% A  = AI + 1i * AQ;
% A(1, 1:2:end) = 1 + 1i;
% A(2, 1:2:end) = 1 - 1i;
% bpsk version
A  = AI;
A(1, 1:2:end) = 1;
A(2, 1:2:end) = -1;

PN = phase_noise(n, 1e-3, 0);
E  = exp(1i * ones(2, 1) * PN);

ps = mean(calcrms((T * A).').^2);
W  = gaussian_noise(2, n, ps/100, 'linear', 'complex');

% channel
B = T * A .* E + W;

% #1 phase noise estimation, 

% >>>>> problem occurs when power of T*[1,1] goes low
% pp = sum(B(:, 1:2:end));

% chose the larger pilot when the power ratio between x and y exceeds
% threshold
p1  = calcrms(B(1, 1:2:end)).^2;
p2  = calcrms(B(2, 1:2:end)).^2;
ppr = max(p1/p2, p2/p1);
if ppr >= 40
    [~, pndx] = max([p1, p2]);
    pp = interp1(1:2:n, B(pndx, 1:2:end), 1:n, 'spline');
    PN_est = unwrap(angle(pp));
else
    pp1 = interp1(1:2:n, B(1, 1:2:end), 1:n, 'spline');
    pp2 = interp1(1:2:n, B(2, 1:2:end), 1:n, 'spline');
    PN_est_1 = unwrap(angle(pp1));
    PN_est_2 = unwrap(angle(pp2));
    PN_est   = (PN_est_1 + PN_est_2) / 2;
end

% the following hack is not necessary for polarization demux but is good
% for illustrating T and T_e
PN_est = PN_est - mean(PN_est) + mean(PN);

figure(1); plot(PN); hold on; plot(PN_est); grid on; hold off;
title(sprintf('power of pilot is %.4f and %.4f with ratio %.4f', p1, p2, ppr));

% #2 remove phase noise followed by least squares estimation of sop
B = B .* exp(-1i * ones(2, 1) * PN_est);

% >>>>> problem occurs when power of T*[1,1] goes low and phase noise
% estimation is bad
% T_e = B * A' * inv(A * A');
T_e = B * A' / (A * A');

figure(2)
subplot(211); stem(real(T(1:4)), 'filled'); hold on;
stem(real(T_e(1:4)), 'filled'); grid on; hold off;
ylim([-1, 1]); ylabel('Re(T)');
subplot(212); stem(imag(T(1:4)), 'filled'); hold on;
stem(imag(T_e(1:4)), 'filled'); grid on; hold off;
ylim([-1, 1]); ylabel('Re(T)');

% #3 sop correction using lmmse filter
% >>>>> problem occurs when T becomes more singular
A_e = (T_e' * T_e + 0.01 * eye(2)) \ T_e' * B;
A_e = A_e ./ mean(calcrms(A_e));
figure(3); plot(A_e(1, :), '.'); hold on;
plot(A_e(2, :), '.'); hold off; grid on;
xlim([-2, 2]); ylim([-2, 2]); 
title(sprintf('det(T^HT) = %.4f', det(T_e' * T_e)));
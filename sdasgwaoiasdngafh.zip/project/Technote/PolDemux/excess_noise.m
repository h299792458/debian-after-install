function dpn = excess_noise(dsnr)
% Calculate the ratio of excess noise to original noise due to a change of
% snr (db)
%----------------------------------------------------------------------------
% Examples: excess_noise(3) should be approximately 1 as the noise is
% doubled to increase the snr by 3db; excess_noise(-3) should be
% approximately -0.5 as the noise is halved to decrease the snr by 3db.
%----------------------------------------------------------------------------
dpn = 10 .^ (dsnr .* 0.1) - 1;
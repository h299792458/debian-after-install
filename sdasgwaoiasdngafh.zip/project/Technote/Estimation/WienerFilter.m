%============================================================================
% This script is dedicated to section 11.7 of the following reference:
% 
% Steven M. Kay, "Fundamentals of statistical signal processing: estimation
% theory." (1993).
%============================================================================
clear
% close all
%----------------------------------------------------------------------------
% Scalar wiener estimator with scalar unknown and scalar observation and
% multiple realizations. The data model is x = s + w, where s and x are
% random variables.
%----------------------------------------------------------------------------
N = 150;
snr = idbw(-5);
var_s = 1;
var_w = var_s./snr;
% random variable with normal distribution, generate a sequence of iid
% samples to represent multiple realizations, generate WGN as well
s = gaussian_noise(N, 1, var_s, 'linear', 'real');
w = gaussian_noise(N, 1, var_w, 'linear', 'real');
x = s + w;
% scalar wiener filter: s_hat becomes x when snr is high, becomes 0 when
% snr is low
s_hat = snr / (snr + 1) * x;

% figure; plot(1:N, s, 1:N, x, 1:N, s_hat); grid on;
%----------------------------------------------------------------------------
% Finite wiener smoother with vector unknowns and vector observations. The
% data model is x = s + w, where x and s are vector random variables or
% blocks of random processes. In this particular example, the unknown is
% assumed to be a section of AR(1) process, the autocorrelation matrix of
% which is given explicitly. Otherwise, estimated autocorrelation matrix
% could be used for finite wiener smoother. Note that the matrix grows
% substantially with the block size and also matrix inversion is needed.
% 
% This method should be compared to the finite wiener smoother implemented
% in frequency domain via DFT, i.e., using the infinite wiener smoother
% given by PSD but implementing only discrete DFT points. The two methods
% have virtually the same performance with exceptional points at two ends
% of the data block. They might have theoretical equivalence yet to be
% proved...
% 
% Another method should also be compared to, e.g., the infinite wiener
% smoother implemented in time domain via linear convolution, but with
% finite impulse response. Multiple design methods could be applied to
% obtain the FIR filter in time domain. 
%----------------------------------------------------------------------------
N = 2000;
snr = idbw(-5);
var_u = 1;
var_w = var_u./snr;
% generate ar(1) process with wgn
a = -0.95;
s = arma(N, 1, [1, a], [1], var_u);
w = gaussian_noise(N, 1, var_w, 'linear', 'real');
x = s + w;

% finite wiener smoother implemented in time domain
Css = zeros(N);
for ii = 1:N
    for jj = 1:N
        Css(ii, jj) = var_u / (1 - a^2) * (-a)^abs(ii-jj);
    end
end
% figure; mesh(1:N,1:N,Css);
s_hat_td = Css / (Css + var_w*eye(N)) * x;

% finite wiener smoother implemented in frequency domain
fs = 1;
freq = get_fft_grid(N, fs);
Pss = var_u ./ abs(1 + a*exp(-1i*2*pi*freq)).^2;
% figure; semilogy(fftshift(freq), fftshift(Pss), 'o-');
Hw = Pss ./ (Pss + var_w);
s_hat_fd = real(ifft(fft(x) .* Hw));

% figure; plot(1:N, s, 1:N, s_hat_td, 1:N, s_hat_fd); grid on;
fprintf('Estimation error variance: TD %f, FD %f\n', var(s-s_hat_td), var(s-s_hat_fd));

% Infinite wiener filter implemented in time domain via digital filter
% design
hfntap = 50;
% Note that "Hw" is a sampled version of true Wiener smoother frequency
% response which is derived from theory in this example. However, taking
% directly the inverse DFT of "Hw" does not generate the sampled version of
% true continuous-time impluse response due to time aliasing (negligible in
% this case).
htmp = ifft(Hw);
h = [htmp(end-hfntap+1:end); htmp(1:hfntap+1)];
h = h ./ sum(abs(h));
% figure; stem(h);
s_hat_td = conv(x, h, 'same');

% figure; plot(1:N, s, 1:N, s_hat_td, 1:N, s_hat_fd); grid on;
fprintf('Estimation error variance: TD %f, FD %f\n', var(s-s_hat_td), var(s-s_hat_fd));
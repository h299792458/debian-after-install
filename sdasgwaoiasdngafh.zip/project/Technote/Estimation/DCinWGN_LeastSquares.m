%============================================================================
% Estimate DC in WGN using LMS filter and RLS filter, where the DC is
% considered deterministic. The two filters can be viewed as the stochastic
% version of gradient descent and Newton method, respectively. As expected,
% RLS filter converges much faster than LMS filter at expense of high
% computation complexity.
% 
% Note that since the unknown DC is deterministic, this is a classic
% estimation problem. However, the LMS filter works as well in non classic
% cases, i.e., it has certain tracking capability. Observe this by
% switching to a periodic DC. The LMS relies solely on the noisy gradient
% calculated based on the current received sample to search for a minimum
% of the cost function.
% 
% On the other hand, instead of searching for minimum, RLS applies Newton's
% method to solve recursively a fixed equation: "derivative of the cost
% function equals zero". However, the cost function may change over time
% and the equation has no universal solution. To equip the RLS with
% tracking capability, the forgetting factor should be incorporated into
% the algorithm.
%============================================================================
clear

nsample = 1500; % sample size
% A = ones(nsample, 1) * 10; % the true mean
f = 1/1000;
A = 10 * cos(2*pi*f*(1:nsample)');
sigma2 = 1; % noise power
w = gaussian_noise(nsample, 1, sigma2, 'linear', 'real');
x = A + w;

% estimation initialization
mu = 0.1;
xe_lms = zeros(size(x));
lambda = 0.99;
gain = zeros(size(x)); % gain
xe_rls = zeros(size(x));
variance = zeros(size(x)); % variance of estimation

for ii = 1 : nsample
    if ii == 1
        xe_lms(ii) = x(1);
        xe_rls(ii) = x(1);
        variance(ii) = sigma2;
    else
        %%% LMS
        xe_lms(ii) = xe_lms(ii-1) + mu * (x(ii)-xe_lms(ii-1));
        %%% RLS
        gain(ii) = variance(ii-1) / (variance(ii-1) + sigma2*lambda);
        xe_rls(ii) = xe_rls(ii-1) + gain(ii) * (x(ii)-xe_rls(ii-1));
        variance(ii) = (1/lambda) * (1-gain(ii)) * variance(ii-1);
    end
end

figure('Unit', 'pixels', 'Position', [500 150 800 600]);
subplot(311); plot(dbw(variance)); grid on; xlabel('samples'); ylabel('variance');
subplot(312); plot(dbw(gain)); grid on; xlabel('samples'); ylabel('gain');
subplot(313); plot(1:nsample, A, 1:nsample, xe_rls, 1:nsample, xe_lms, 'linewidth', 4); grid on;
xlabel('samples'); ylabel('estimated mean'); legend('True', 'RLS', 'LMS');

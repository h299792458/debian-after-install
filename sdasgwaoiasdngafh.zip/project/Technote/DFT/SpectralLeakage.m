%===========================================================================
% A block of data samples can be obtained by multiplying the infinite long
% input data sequence by a rectangular window function, corresponding to
% convoluting the discrete time Fourier transform of input siganl with a
% sinc function, which causes a "blurred" DTFT and the so-called "spectral
% leakage". If only few discrete frequencies in the DTFT are concerned, the
% blurring is analogy of pulse-shaping in time domain, and the spectral
% leakage is analogy of ISI in time domain. 
% 
% As the result of convolution, a Dirac delta in DTFT will be broadened
% into the shape of frequency response H(w) of the window function (sinc
% function in the rect window case). DFT is a sampled version of the
% blurred version of DTFT, and the frequency range from the center of H(w)
% to its first zero is defined as the spectral resolution of DFT as it is
% the minimum frequency separation allowing zero spectral leakage (ISI).
% Note that the DFT is NOT the direct cause of spectral leakage. The
% blurred DTFT has spectral leakage already and DFT is just overlaying a
% frequency grid onto the DTFT and return the "measurements".
% 
% Note that the rect window is a special case in which the zero spectral
% leakage locations conincide exactly with the DFT grid, and therefore no
% spectral leakage will be "observed" by DFT only if the frequencies are on
% the DFT grid.
% 
% A longer time window has narrower H(w), hence will produce a less blurred
% DTFT and increase the DFT sampling resolution. For a given time window,
% zero-padding the time sequence will produce more details of the blurred
% DTFT, but will not increase the effective frequency resolution since
% zero-padding is just equivalent to oversampling a given DTFT.
%===========================================================================

clear
close all

% number of DFT
N = 256;
% freq of signal
f1 = 40;
f2 = 100;
% sampling speed
fs = 800;

%----------------------------------------------------------------------------
% Due to finite length of DTFT, signal is effectively multiplying a
% rectangular windown in time domain, therefore, a single frequency signal
% with a delta DTFT convolves with a sinc function in frequency domain,
% resulting in a sinc-shaped DTFT with zeros spaced by fs/N. DFT returns
% samples of DTFT. 
% 
% If the signal frequency f1 falls on the DFT grid, DFT only returns the f1
% with corect amplitude and zeros elsewhere.
% 
% If the signal frequency f2 falls off the DFT grid, DFT returns nonzero
% samples everywhere, i.e. the energy/power leaks into frequency bins of
% entire DFT.
% 
% In conclusion, the spectral leakage is frequency dependent, and the
% unwindowed DFT resolution is fs/N, i.e. only frequencies falling on zeros
% of sinc pattern can be corrected calculated without any spectral leakage.
%----------------------------------------------------------------------------
% two frequencies signal with f1 off grid and f2 on grid
fm1 = N * f1 / fs;
fm2 = N * f2 / fs;
signal_1 = cos(2 * pi * f1 * (0 : N-1) ./ fs);
signal_2 = cos(2 * pi * f2 * (0 : N-1) ./ fs);
signal = signal_1 + signal_2;
signal = sqrt(2) * signal ./ calcrms(signal);
freq_1 = get_fft_grid(N, fs);
psd_1 = periodogram(signal, N);

% power consistency
et = calcrms(signal).^2;
ef = sum(psd_1);
fprintf('Power in time domain is %.4f \n', et);
fprintf('Power in freq domain is %.4f \n', ef);

figure;
plot(fftshift(freq_1), dbw(fftshift(2*psd_1)), '+-', 'LineWidth', 2); hold on; 

%----------------------------------------------------------------------------
% zero-padding the data samples will NOT increase the actual frequency
% resolution, but only to calculate and show more details of the window
% pattern...even if frequency 2 falls exactly on one of the DFT grid,
% spectral leakage still can be observed under zeropadding.
%----------------------------------------------------------------------------
L = 80000;
freq_2 = get_fft_grid(L, fs);
psd_2 = periodogram(signal, L) * L^2 / N^2;

plot(fftshift(freq_2), dbw(fftshift(2*psd_2)), '.-', 'LineWidth', 1); grid on;

%----------------------------------------------------------------------------
% Increase N will increase the actual unwindowed DFT resolution (fs/N) as
% now frequencies have more chance to fit in the DFT grid
%----------------------------------------------------------------------------
N = 800;
freq = get_fft_grid(N, fs);
% the maximal energy in frequency, should be integer index
fm1 = N * f1 / fs;
fm2 = N * f2 / fs;
signal = cos(2 * pi * f1 * (0 : N-1) ./ fs) + cos(2 * pi * f2 * (0 : N-1) ./ fs);
signal = sqrt(2) * signal ./ calcrms(signal);
psd = periodogram(signal, N);

plot(fftshift(freq), dbw(fftshift(2*psd)), '-', 'LineWidth', 2); grid on
xlabel('Frequency (Hz)'); 
ylabel('Power (dB)');
legend('nfft = 256', ['nfft = 256, zero-padded to ', num2str(L)], 'nfft = 800');
xlim([0, 200]);
ylim([-50, 10]);

%----------------------------------------------------------------------------
% Observe the spetral leakage: 
% 
% I - f1 cause serious spectral leakage. f1 in the 1st case is off the DFT
% grid, therefore, DFT returns nonzero samples everywhere. This spectral
% leakage causes a power increas of f2, power of which should be 1 in
% principle. Observe the slight power increase of f2 in case #1. In
% practice, it is better to put high-power frequencies ON the DFT grid to
% avoid serious spectral leakage, if no windowing technique is desired.
% 
% II - DFT samples of f1 and f2 in the 1st case fall exactly on the
% zero-padded DFT curve in the 2nd case, which is reasonable since the 2nd
% case is just the more detailed version of 1st one. No spectral leakage is
% alleviated.
% 
% III - in case #3, both f1 and f2 are on the DFT grid, hence no spectral
% leakage in the rect window case, both frequencies have exact power of 1.
%----------------------------------------------------------------------------

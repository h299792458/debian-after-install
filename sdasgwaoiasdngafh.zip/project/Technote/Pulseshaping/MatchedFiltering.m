%===========================================================================
% This script calculates the theoretical ber of m-qam signal in gaussian
% noise using multiple sample per symbol with pulse-shaping considered in
% this version. It is shown that the real SNR is obtained by doing matched
% filtering at the receiver.
%===========================================================================
function [] = MatchedFiltering(k)
if nargin < 1, k = 1; end

sps = 16;
nsymbol = 2^16;
nsample = sps * nsymbol;
bits_tx = randi([0 1], k, nsymbol);
baud_tx = mqammod(bits_tx);

alpha = 0.35;
H = frequency_response(nsample, sps, alpha, 1, 'rrc');
baud_up = upsample(baud_tx(:), sps);
a = real(ifft(fft(real(baud_up)) .* H));
b = real(ifft(fft(imag(baud_up)) .* H));
tx = a + 1i * b;

% get the signal power which is the power of information
symbol_power = calcrms(tx).^2;
snr = -10 : .1 : 10;
for ndx = 1 : length(snr)
    % noise power in the whole spectrum, obtained by multiplying the noise
    % power per symbol by the oversampling factor
    pn = symbol_power / idbw(snr(ndx)) * sps;
    rx = tx + gaussian_noise(size(tx,1), size(tx,2), pn, 'linear', 'complex');

    % matched filtering
    a = real(ifft(fft(real(rx)) .* H));
    b = real(ifft(fft(imag(rx)) .* H));
    baud = a(1:sps:end) + 1i * b(1:sps:end);
    bits = qamdemod(baud, 2^k);
    if k == 1, bits = bits.'; end
    ber(ndx) = sum(sum(abs(bits - bits_tx))) / numel(bits_tx);
    fprintf('snr = %.1f, ber = %.4e\n', snr(ndx), ber(ndx));
end

% Theoretical BER in AWGN. Note that the input should be EbNo. For BPSK,
% SNR is doubled since only the real part of noise counts.
if k == 1 
    t_ber = berawgn(snr + dbw(2) - dbw(2), 'psk', 2, 'nodiff');
else
    t_ber = berawgn(snr - dbw(k), 'qam', 2^k);
end

figure;
semilogy(snr, t_ber, 'k-', snr, ber, 's-'); grid on
xlabel('SNR dB'); 
ylabel('LOG10 BER'); 
legend('Theory', mn2mf(2^k));

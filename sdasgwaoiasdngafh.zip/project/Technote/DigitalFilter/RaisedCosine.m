clear
close all

% impulse response
x = -6 : 0.01 : 6;
y = sinc(x);
T = 1;
t = -6 : 0.01 : 6;
figure; plot(x, y, 'k', 'LineWidth', 1); grid on; box on; hold on

alpha = 0.202;
h = sin(pi*t./T) ./ (pi*t/T) .* cos(alpha * pi * t / T) ./ (1 - 4 * alpha^2 * t.^2 / T^2);
plot(t, h, 'k--', 'LineWidth', 1);

alpha = 0.35;
h = sin(pi*t./T) ./ (pi*t/T) .* cos(alpha * pi * t / T) ./ (1 - 4 * alpha^2 * t.^2 / T^2);
plot(t, h, 'k-.', 'LineWidth', 1);

x = -6 : 6;
y = sinc(x);
stem(x, y, 'k', 'LineWidth', 2);
ylim([-.4, 1.2])
legend('Perfect Sinc', 'Raised Cosine 0.2', 'Raised Cosine 0.35', 'Samples');

% frequency response
nsample = 2^12;
fs = 2;
bandwidth = 1;
type = 'rc';
order = 0.00002;
H = frequency_response(nsample, fs, order, bandwidth, type);
freq = get_fft_grid(nsample, fs);
figure; plot(fftshift(freq), fftshift(H), 'k-'); grid on; hold on; box on;

order = 0.2;
H = frequency_response(nsample, fs, order, bandwidth, type);
freq = get_fft_grid(nsample, fs);
plot(fftshift(freq), fftshift(H), 'k--'); 

order = 0.35;
H = frequency_response(nsample, fs, order, bandwidth, type);
freq = get_fft_grid(nsample, fs);
plot(fftshift(freq), fftshift(H), 'k-.'); 
ylim([-0.2, 1.2]);
legend('Perfect Rectangular', 'Raised Cosine 0.2', 'Raised Cosine 0.35');
